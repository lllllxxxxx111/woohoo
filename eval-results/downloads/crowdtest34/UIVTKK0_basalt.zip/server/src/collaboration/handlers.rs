use axum::{
    extract::{Path, Query, State},
    http::HeaderMap,
    response::sse::{Event, KeepAlive, Sse},
    Json,
};
use futures::stream::Stream;
use serde_json::json;
use std::convert::Infallible;

use crate::ai::{
    client::StreamFallbackMode, config::AiChatReq, handlers::enqueue_ai_task_for_request,
    usage::AiUsageOperation,
};
use crate::auth::middleware::UserId;
use crate::error::AppError;
use crate::AppState;

use super::dispatcher::{self, DispatchItem};
use super::loop_detector;
use super::model::*;
use super::readiness;
use super::repo;

/// 校验会话归属当前用户，防止越权访问
async fn verify_session_owner(
    state: &AppState,
    session_id: &str,
    user_id: &UserId,
) -> Result<CollaborationSession, AppError> {
    let session = repo::get_session(&state.db, session_id)
        .await
        .map_err(|e| AppError::NotFound(format!("协同会话不存在: {}", e)))?;

    if session.user_id != user_id.0 {
        return Err(AppError::Forbidden("无权访问此协同会话".to_string()));
    }

    Ok(session)
}

/// 广播协同事件到 SSE channel
fn broadcast_collaboration_event(
    state: &AppState,
    session_id: &str,
    event_type: &str,
    payload: Option<serde_json::Value>,
) {
    state
        .collaboration_broadcaster
        .broadcast(session_id.to_string(), event_type, payload);
}

/// 创建协同会话
pub async fn create_session(
    axum::extract::State(state): axum::extract::State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Json(req): Json<CreateSessionReq>,
) -> Result<Json<CollaborationSession>, AppError> {
    let session = repo::create_session(
        &state.db,
        &user_id.0,
        &req.project_id,
        &req.conversation_id,
        req.entry_message_id.as_deref(),
        req.orchestrator_agent_id.as_deref(),
    )
    .await
    .map_err(|e| AppError::Internal(e.to_string()))?;

    let payload = json!({
        "sessionId": session.id,
        "projectId": session.project_id,
        "state": session.state
    });

    let _ = repo::create_event(
        &state.db,
        &session.id,
        "collaboration_session_created",
        Some(&payload.to_string()),
    )
    .await;

    broadcast_collaboration_event(
        &state,
        &session.id,
        "collaboration_session_created",
        Some(payload),
    );

    Ok(Json(session))
}

/// 查询协同会话详情
pub async fn get_session(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
) -> Result<Json<SessionSummary>, AppError> {
    let session = verify_session_owner(&state, &session_id, &user_id).await?;

    let assignments = repo::list_assignments(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    Ok(Json(SessionSummary {
        session,
        assignments,
    }))
}

/// 查询项目当前活跃协同会话
pub async fn get_active_session(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Query(params): Query<ActiveSessionQuery>,
) -> Result<Json<Option<SessionSummary>>, AppError> {
    let sessions = repo::list_active_sessions_for_project(
        &state.db,
        &user_id.0,
        &params.project_id,
        params.conversation_id.as_deref(),
    )
    .await
    .map_err(|e| AppError::Internal(e.to_string()))?;

    let session = match sessions.into_iter().next() {
        Some(s) => s,
        None => return Ok(Json(None)),
    };

    let assignments = repo::list_assignments(&state.db, &session.id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    Ok(Json(Some(SessionSummary {
        session,
        assignments,
    })))
}

/// 根据当前对话内容判断是否可以启动协同
pub async fn get_readiness(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Query(params): Query<ReadinessQuery>,
) -> Result<Json<CollaborationReadinessResponse>, AppError> {
    let conversation = crate::conversation::repo::find_by_id(&state.db, &params.conversation_id)
        .await?
        .ok_or_else(|| AppError::NotFound("对话不存在".to_string()))?;
    if conversation.user_id != user_id.0 {
        return Err(AppError::Forbidden("无权访问该对话".to_string()));
    }

    let messages = crate::conversation::repo::list_messages(&state.db, &params.conversation_id)
        .await?
        .into_iter()
        .map(|message| message.content)
        .collect::<Vec<_>>();
    let result = readiness::evaluate(&messages);
    Ok(Json(CollaborationReadinessResponse {
        ready: result.ready,
        missing: result.missing,
    }))
}

/// 编导分派任务
pub async fn dispatch(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
    Json(req): Json<DispatchReq>,
) -> Result<Json<DispatchResponse>, AppError> {
    verify_session_owner(&state, &session_id, &user_id).await?;

    let items: Vec<DispatchItem> = req
        .assignments
        .into_iter()
        .map(|a| DispatchItem {
            agent_id: a.agent_id,
            task_type: a.task_type,
            goal: a.goal,
            depends_on: a.depends_on,
            input: a.input,
        })
        .collect();

    let result = dispatcher::Dispatcher::dispatch_assignments(&state.db, &session_id, items)
        .await
        .map_err(|e| AppError::BadRequest(e.to_string()))?;

    dispatch_ready_assignments(&state, &user_id.0, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;
    let linked_assignments = repo::list_assignments(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    let payload = json!({
        "dispatchedCount": result.dispatched_count,
        "sessionId": session_id,
        "state": SessionState::ResolvingQuestions.as_str()
    });

    broadcast_collaboration_event(
        &state,
        &session_id,
        "collaboration_dispatched",
        Some(payload),
    );

    if linked_assignments
        .iter()
        .any(|assignment| assignment.status == "failed")
    {
        let _ = halt_failed_session(&state, &session_id, "协同任务创建失败").await;
    }

    Ok(Json(DispatchResponse {
        dispatched_count: result.dispatched_count as i64,
        assignments: linked_assignments,
    }))
}

pub(crate) async fn dispatch_ready_assignments(
    state: &AppState,
    user_id: &str,
    session_id: &str,
) -> anyhow::Result<()> {
    let session = repo::get_session(&state.db, session_id).await?;
    let assignments = repo::list_assignments(&state.db, session_id).await?;
    let messages = repo::list_messages(&state.db, session_id).await?;

    for assignment in assignments.iter().filter(|assignment| {
        matches!(assignment.status.as_str(), "assigned" | "ready")
            && assignment.ai_task_id.is_none()
            && dependencies_satisfied(assignment, &assignments)
    }) {
        let Some(claimed) = repo::claim_assignment_for_execution(&state.db, &assignment.id).await?
        else {
            continue;
        };
        broadcast_collaboration_event(
            state,
            session_id,
            "collaboration_assignment_updated",
            Some(json!({
                "assignmentId": claimed.id,
                "agentId": claimed.agent_id,
                "newStatus": claimed.status,
            })),
        );

        let dependency_context = dependency_output_context(&claimed, &messages);
        let input_context = claimed.input_json.as_deref().unwrap_or("无额外输入");
        let task_prompt = format!(
            "你正在参与项目内多智能体协同。\n任务类型：{}\n任务目标：{}\n任务输入：{}{}\n请直接给出可供其他智能体继续工作的明确产出，不要反问用户。",
            claimed.task_type, claimed.goal, input_context, dependency_context
        );
        let req = AiChatReq {
            conversation_id: session.conversation_id.clone(),
            content: task_prompt,
            resource_refs: None,
            agent_id: Some(claimed.agent_id.clone()),
            endpoint_id: None,
            model: None,
            force_stream_fallback: Some(true),
            system_prompt: None,
            temperature: None,
            top_p: None,
            frequency_penalty: None,
            max_tokens: None,
            output_kind: Some("document".to_string()),
            output_items: Some(1),
            allow_assistant_actions: false,
            confirmed_message_id: None,
            confirmed_workflow_guard_message_id: None,
            trigger_source: Some("collaboration".to_string()),
        };

        match enqueue_ai_task_for_request(
            state,
            user_id,
            req,
            AiUsageOperation::Task,
            StreamFallbackMode::Force,
        )
        .await
        {
            Ok(task) => {
                let linked =
                    repo::link_assignment_ai_task(&state.db, &claimed.id, &task.id).await?;
                let next_order = repo::get_next_queue_order(&state.db, session_id).await?;
                let _ = repo::create_message(
                    &state.db,
                    session_id,
                    session.orchestrator_agent_id.as_deref(),
                    Some(&linked.agent_id),
                    MessageKind::Assign.as_str(),
                    &linked.goal,
                    None,
                    None,
                    next_order,
                )
                .await;
                broadcast_collaboration_event(
                    state,
                    session_id,
                    "collaboration_assignment_updated",
                    Some(json!({
                        "assignmentId": linked.id,
                        "agentId": linked.agent_id,
                        "newStatus": linked.status,
                        "aiTaskId": linked.ai_task_id,
                    })),
                );
                if let Some(current_task) = state.ai_runtime.get_task(user_id, &task.id).await {
                    if matches!(
                        current_task.status,
                        crate::ai::config::AiTaskStatus::Completed
                            | crate::ai::config::AiTaskStatus::Failed
                            | crate::ai::config::AiTaskStatus::Cancelled
                            | crate::ai::config::AiTaskStatus::Blocked
                    ) {
                        Box::pin(super::worker::sync_terminal_task(state, &current_task)).await?;
                    }
                }
            }
            Err(error) => {
                let failed = repo::update_assignment_status(
                    &state.db,
                    &claimed.id,
                    AssignmentStatus::Failed.as_str(),
                )
                .await?;
                broadcast_collaboration_event(
                    state,
                    session_id,
                    "collaboration_assignment_updated",
                    Some(json!({
                        "assignmentId": failed.id,
                        "agentId": failed.agent_id,
                        "newStatus": failed.status,
                        "error": error.to_string(),
                    })),
                );
                halt_failed_session(state, session_id, "协同任务创建失败").await?;
                return Err(anyhow::anyhow!(error.to_string()));
            }
        }
    }

    Ok(())
}

fn assignment_dependencies(assignment: &CollaborationAssignment) -> Vec<String> {
    assignment
        .depends_on_json
        .as_deref()
        .and_then(|value| serde_json::from_str::<Vec<String>>(value).ok())
        .unwrap_or_default()
}

fn dependencies_satisfied(
    assignment: &CollaborationAssignment,
    assignments: &[CollaborationAssignment],
) -> bool {
    assignment_dependencies(assignment)
        .into_iter()
        .all(|dependency| {
            assignments
                .iter()
                .find(|candidate| candidate.agent_id == dependency)
                .is_some_and(|candidate| candidate.status == "done")
        })
}

fn dependency_output_context(
    assignment: &CollaborationAssignment,
    messages: &[CollaborationMessage],
) -> String {
    let dependencies = assignment_dependencies(assignment);
    let outputs = dependencies
        .iter()
        .filter_map(|agent_id| {
            messages
                .iter()
                .rev()
                .find(|message| {
                    message.source_agent_id.as_deref() == Some(agent_id.as_str())
                        && message.message_kind == MessageKind::Status.as_str()
                })
                .map(|message| format!("\n上游智能体 {} 的产出：\n{}", agent_id, message.content))
        })
        .collect::<String>();
    if outputs.is_empty() {
        String::new()
    } else {
        format!("\n依赖任务产出：{}", outputs)
    }
}

/// 发送协同消息
pub async fn send_message(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
    Json(req): Json<SendMessageReq>,
) -> Result<Json<CollaborationMessage>, AppError> {
    verify_session_owner(&state, &session_id, &user_id).await?;

    let message_kind =
        MessageKind::try_from(req.message_kind.as_str()).map_err(AppError::BadRequest)?;

    let message = match &message_kind {
        MessageKind::Question => dispatcher::Dispatcher::handle_question(
            &state.db,
            &session_id,
            req.source_agent_id.as_deref().unwrap_or(""),
            req.target_agent_id.as_deref().unwrap_or(""),
            &req.content,
            req.question_fingerprint.as_deref(),
        )
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?,
        MessageKind::Answer => dispatcher::Dispatcher::handle_answer(
            &state.db,
            &session_id,
            req.source_agent_id.as_deref().unwrap_or(""),
            req.target_agent_id.as_deref().unwrap_or(""),
            &req.content,
            req.reply_to_message_id.as_deref(),
        )
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?,
        _ => {
            let next_order = repo::get_next_queue_order(&state.db, &session_id)
                .await
                .map_err(|e| AppError::Internal(e.to_string()))?;

            let msg = repo::create_message(
                &state.db,
                &session_id,
                req.source_agent_id.as_deref(),
                req.target_agent_id.as_deref(),
                message_kind.as_str(),
                &req.content,
                req.question_fingerprint.as_deref(),
                req.reply_to_message_id.as_deref(),
                next_order,
            )
            .await
            .map_err(|e| AppError::Internal(e.to_string()))?;

            let _ = repo::increment_round_count(&state.db, &session_id).await;
            msg
        }
    };

    let payload = json!({
        "messageId": message.id,
        "messageKind": message.message_kind,
        "sourceAgentId": message.source_agent_id,
        "targetAgentId": message.target_agent_id,
    });

    broadcast_collaboration_event(
        &state,
        &session_id,
        "collaboration_message_sent",
        Some(payload),
    );

    if let Err(error) = apply_automatic_loop_check(&state, &session_id).await {
        tracing::warn!(session_id = %session_id, error = %error, "自动循环检测失败");
    }

    Ok(Json(message))
}

async fn apply_automatic_loop_check(state: &AppState, session_id: &str) -> anyhow::Result<()> {
    let signals = loop_detector::LoopDetector::detect(&state.db, session_id).await?;
    if signals.is_empty() {
        return Ok(());
    }

    let session = repo::get_session(&state.db, session_id).await?;
    let level = loop_detector::LoopDetector::calculate_level(&signals, session.round_count);
    let signal_strings = signals
        .iter()
        .map(|signal| signal.as_str().to_string())
        .collect::<Vec<_>>();
    let action = if level >= 4 {
        "halt_session"
    } else if level >= 2 {
        "escalate_to_director"
    } else {
        "warn_current_agent"
    };
    let payload = json!({
        "level": level,
        "signals": signal_strings,
        "action": action,
        "message": if level >= 4 { "达到自动讨论轮数上限" } else { "检测到协同循环风险" },
    });
    repo::update_loop_status(&state.db, session_id, &payload.to_string()).await?;
    let _ = repo::create_event(
        &state.db,
        session_id,
        "collaboration_loop_warning",
        Some(&payload.to_string()),
    )
    .await;
    broadcast_collaboration_event(
        state,
        session_id,
        "collaboration_loop_warning",
        Some(payload),
    );

    if level >= 4 {
        halt_failed_session(state, session_id, "达到自动讨论轮数上限").await?;
    }
    Ok(())
}

/// 获取协同会话消息列表
pub async fn list_messages(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
) -> Result<Json<Vec<CollaborationMessage>>, AppError> {
    verify_session_owner(&state, &session_id, &user_id).await?;

    let messages = repo::list_messages(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    Ok(Json(messages))
}

/// 循环检测
pub async fn loop_check(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
) -> Result<Json<LoopCheckResponse>, AppError> {
    verify_session_owner(&state, &session_id, &user_id).await?;

    let signals = loop_detector::LoopDetector::detect(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    if signals.is_empty() {
        return Ok(Json(LoopCheckResponse {
            loop_detected: false,
            signals: vec![],
            level: 0,
            action: "none".to_string(),
            message: "未检测到循环风险".to_string(),
        }));
    }

    let session = repo::get_session(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    let level = loop_detector::LoopDetector::calculate_level(&signals, session.round_count);

    let (action, message) = match level {
        1 => (
            "warn_current_agent".to_string(),
            "检测到循环风险：要求当前智能体改写为明确问题".to_string(),
        ),
        2 => (
            "escalate_to_director".to_string(),
            "检测到循环风险：已升级给编导重新拆解任务".to_string(),
        ),
        3 => (
            "escalate_to_user".to_string(),
            "检测到严重循环风险：请求用户裁决".to_string(),
        ),
        4 => (
            "halt_session".to_string(),
            "协同会话已暂停：达到自动讨论轮数上限".to_string(),
        ),
        _ => ("unknown".to_string(), "未知循环风险等级".to_string()),
    };

    let signal_strings: Vec<String> = signals.iter().map(|s| s.as_str().to_string()).collect();

    if level >= 4 {
        let _ =
            repo::update_session_state(&state.db, &session_id, SessionState::Halted.as_str()).await;
    }

    let payload = json!({
        "level": level,
        "signals": signal_strings,
        "action": action
    });

    let _ = repo::update_loop_status(&state.db, &session_id, &payload.to_string()).await;

    let _ = repo::create_event(
        &state.db,
        &session_id,
        "collaboration_loop_warning",
        Some(&payload.to_string()),
    )
    .await;

    broadcast_collaboration_event(
        &state,
        &session_id,
        "collaboration_loop_warning",
        Some(payload),
    );

    Ok(Json(LoopCheckResponse {
        loop_detected: true,
        signals: signal_strings,
        level,
        action,
        message,
    }))
}

/// 入工作区判定（含成熟度检查 + 自动创建 pipeline_run）
pub async fn admit(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
) -> Result<Json<AdmitResponse>, AppError> {
    let session = verify_session_owner(&state, &session_id, &user_id).await?;
    Ok(Json(admit_session(&state, session).await?))
}

/// 当所有协同任务成功完成时自动进入工作区。
pub(crate) async fn try_auto_admit(
    state: &AppState,
    session_id: &str,
) -> Result<Option<AdmitResponse>, AppError> {
    let session = repo::get_session(&state.db, session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;
    if !matches!(
        session.state.as_str(),
        "resolving_questions" | "workspace_admission"
    ) {
        return Ok(None);
    }

    let assignments = repo::list_assignments(&state.db, session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;
    if assignments.is_empty()
        || !assignments
            .iter()
            .all(|assignment| assignment.status == "done")
    {
        return Ok(None);
    }

    Ok(Some(admit_session(state, session).await?))
}

pub(crate) async fn halt_failed_session(
    state: &AppState,
    session_id: &str,
    reason: &str,
) -> anyhow::Result<()> {
    let session = repo::get_session(&state.db, session_id).await?;
    if matches!(session.state.as_str(), "completed" | "halted") {
        return Ok(());
    }
    let updated =
        repo::update_session_state(&state.db, session_id, SessionState::Halted.as_str()).await?;
    let payload = json!({ "reason": reason, "state": updated.state });
    let _ = repo::create_event(
        &state.db,
        session_id,
        "collaboration_session_halted",
        Some(&payload.to_string()),
    )
    .await;
    broadcast_collaboration_event(
        state,
        session_id,
        "collaboration_session_halted",
        Some(payload),
    );
    Ok(())
}

async fn admit_session(
    state: &AppState,
    session: CollaborationSession,
) -> Result<AdmitResponse, AppError> {
    let session_id = session.id.clone();

    let current_state =
        SessionState::try_from(session.state.as_str()).map_err(|e| AppError::BadRequest(e))?;

    if current_state != SessionState::ResolvingQuestions
        && current_state != SessionState::WorkspaceAdmission
    {
        return Err(AppError::BadRequest(format!(
            "当前状态 {} 不允许入工作区判定",
            session.state
        )));
    }

    let assignments = repo::list_assignments(&state.db, &session_id)
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    // 成熟度检查：阻塞中的智能体
    let blocked: Vec<&CollaborationAssignment> = assignments
        .iter()
        .filter(|a| a.status == "blocked" || a.status == "questioning")
        .collect();

    if !blocked.is_empty() {
        let blocking_issues: Vec<BlockingIssue> = blocked
            .iter()
            .map(|a| BlockingIssue {
                assignment_id: a.id.clone(),
                agent_id: a.agent_id.clone(),
                question: format!("智能体 {} 仍有未解决的阻塞问题", a.agent_id),
                status: a.status.clone(),
            })
            .collect();

        return Ok(AdmitResponse {
            admitted: false,
            pipeline_run_id: None,
            reason: format!("仍有 {} 个阻塞问题未解决，无法入场", blocked.len()),
            blocking_issues: Some(blocking_issues),
        });
    }

    // 成熟度检查：关键角色就绪状态
    let readiness = evaluate_readiness(&assignments);

    if !readiness.can_admit {
        return Ok(AdmitResponse {
            admitted: false,
            pipeline_run_id: None,
            reason: readiness.reason,
            blocking_issues: None,
        });
    }

    repo::update_session_state(
        &state.db,
        &session_id,
        SessionState::WorkspaceAdmission.as_str(),
    )
    .await
    .map_err(|e| AppError::Internal(e.to_string()))?;

    if let Err(e) = repo::update_admission_decision(
        &state.db,
        &session_id,
        &json!({"admitted": true, "reason": &readiness.reason}).to_string(),
    )
    .await
    {
        tracing::warn!(session_id = %session_id, error = %e, "更新入场判定记录失败");
    }

    // 入场成功后自动创建 pipeline_run
    let pipeline_run_id =
        match create_pipeline_from_collaboration(state, &session, &assignments).await {
            Ok(pipeline_run_id) => pipeline_run_id,
            Err(error) => {
                let failure_payload = json!({
                    "admitted": false,
                    "sessionId": session_id,
                    "pipelineRunId": null,
                    "error": error.to_string(),
                });
                let _ = repo::update_admission_decision(
                    &state.db,
                    &session_id,
                    &failure_payload.to_string(),
                )
                .await;
                let _ = repo::create_event(
                    &state.db,
                    &session_id,
                    "collaboration_admission_changed",
                    Some(&failure_payload.to_string()),
                )
                .await;
                broadcast_collaboration_event(
                    state,
                    &session_id,
                    "collaboration_admission_changed",
                    Some(failure_payload),
                );
                return Err(error);
            }
        };

    let payload = json!({
        "admitted": true,
        "sessionId": session_id,
        "pipelineRunId": pipeline_run_id
    });

    if let Err(e) = repo::create_event(
        &state.db,
        &session_id,
        "collaboration_admission_changed",
        Some(&payload.to_string()),
    )
    .await
    {
        tracing::warn!(session_id = %session_id, error = %e, "创建入场事件记录失败");
    }

    broadcast_collaboration_event(
        &state,
        &session_id,
        "collaboration_admission_changed",
        Some(payload),
    );

    let workspace_payload = json!({
        "sessionId": session_id,
        "pipelineRunId": pipeline_run_id,
        "state": "workspace_execution"
    });
    broadcast_collaboration_event(
        state,
        &session_id,
        "collaboration_workspace_started",
        Some(workspace_payload),
    );

    Ok(AdmitResponse {
        admitted: true,
        pipeline_run_id: Some(pipeline_run_id),
        reason: readiness.reason,
        blocking_issues: None,
    })
}

/// 暂停协同
pub async fn halt(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    Path(session_id): Path<String>,
    Json(req): Json<HaltReq>,
) -> Result<Json<CollaborationSession>, AppError> {
    let session = verify_session_owner(&state, &session_id, &user_id).await?;

    let current_state =
        SessionState::try_from(session.state.as_str()).map_err(|e| AppError::BadRequest(e))?;

    if current_state == SessionState::Completed || current_state == SessionState::Halted {
        return Err(AppError::BadRequest(format!(
            "当前状态 {} 不允许暂停",
            session.state
        )));
    }

    let session = repo::update_session_state(&state.db, &session_id, SessionState::Halted.as_str())
        .await
        .map_err(|e| AppError::Internal(e.to_string()))?;

    let payload = json!({
        "reason": req.reason,
        "detail": req.detail
    });

    if let Err(e) = repo::create_event(
        &state.db,
        &session_id,
        "collaboration_session_halted",
        Some(&payload.to_string()),
    )
    .await
    {
        tracing::warn!(session_id = %session_id, error = %e, "创建暂停事件记录失败");
    }

    broadcast_collaboration_event(
        &state,
        &session_id,
        "collaboration_session_halted",
        Some(payload),
    );

    Ok(Json(session))
}

/// 协同事件 SSE 流
/// Supports Last-Event-ID header for resuming from a specific event sequence.
/// Event IDs use format "collab-{seq}".
pub async fn stream_collaboration_events(
    State(state): State<AppState>,
    axum::extract::Extension(user_id): axum::extract::Extension<UserId>,
    headers: HeaderMap,
) -> Sse<impl Stream<Item = Result<Event, Infallible>>> {
    let user_id = user_id.0.clone();
    let db = state.db.clone();

    // Parse cursor from Last-Event-ID
    let cursor_seq = headers
        .get("last-event-id")
        .and_then(|v| v.to_str().ok())
        .and_then(super::broadcast::CollaborationBroadcaster::parse_event_id);

    let mut rx = state.collaboration_broadcaster.subscribe();

    let broadcaster = state.collaboration_broadcaster.clone();
    let user_id_clone = user_id.clone();

    let stream = async_stream::stream! {
        // Stamp resync/catch-up events with the broadcaster's current seq so
        // that after a gap the client's Last-Event-ID advances past the lost
        // region rather than pinning at the stale cursor (which would cause
        // resync on every reconnect).
        let current_seq = broadcaster.current_event_seq();

        // Replay buffered events if cursor provided
        if let Some(after_seq) = cursor_seq {
            let (replayed, has_gap) = broadcaster.replay_events_after(after_seq);
            if has_gap {
                yield Ok(Event::default()
                    .event("resync_required")
                    // Use current_seq (not the stale after_seq) so cursor advances
                    .id(super::broadcast::CollaborationBroadcaster::format_event_id(current_seq))
                    .data(json!({
                        "reason": "cursor_expired",
                        "message": "协同事件游标已过期，请重新同步"
                    }).to_string()));
                // Resubscribe for future events; client must do full resync via HTTP
                rx = broadcaster.subscribe();
            } else {
                for evt in replayed {
                    // Check ownership
                    let is_owner = sqlx::query_scalar::<_, i64>(
                        "SELECT COUNT(*) FROM collaboration_sessions WHERE id = ? AND user_id = ?"
                    )
                    .bind(&evt.session_id)
                    .bind(&user_id_clone)
                    .fetch_one(&db)
                    .await
                    .unwrap_or(0);

                    if is_owner > 0 {
                        let data = json!({
                            "sessionId": evt.session_id,
                            "eventType": evt.event_type,
                            "payload": evt.payload
                        }).to_string();
                        yield Ok(Event::default()
                            .event("collaboration")
                            .id(super::broadcast::CollaborationBroadcaster::format_event_id(evt.seq))
                            .data(data));
                    }
                }
            }
        }

        let mut last_seen_seq = cursor_seq.unwrap_or(0);

        loop {
            match rx.recv().await {
                Ok(envelope) => {
                    // Check ownership
                    let is_owner = sqlx::query_scalar::<_, i64>(
                        "SELECT COUNT(*) FROM collaboration_sessions WHERE id = ? AND user_id = ?"
                    )
                    .bind(&envelope.session_id)
                    .bind(&user_id)
                    .fetch_one(&db)
                    .await
                    .unwrap_or(0);

                    if is_owner == 0 {
                        continue;
                    }

                    last_seen_seq = last_seen_seq.max(envelope.seq);

                    let data = json!({
                        "sessionId": envelope.session_id,
                        "eventType": envelope.event_type,
                        "payload": envelope.payload
                    }).to_string();
                    yield Ok(Event::default()
                        .event("collaboration")
                        .id(super::broadcast::CollaborationBroadcaster::format_event_id(envelope.seq))
                        .data(data));
                }
                Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => {
                    // On lag, send resync signal, resubscribe, and replay any buffered events after last_seen_seq
                    yield Ok(Event::default()
                        .event("resync_required")
                        .data(json!({
                            "reason": "lagged",
                            "message": "协同事件积压，正在重新同步"
                        }).to_string()));
                    rx = broadcaster.subscribe();
                    // Replay events that occurred after our last seen seq from the buffer
                    let (replayed, _) = broadcaster.replay_events_after(last_seen_seq);
                    for evt in replayed {
                        let is_owner = sqlx::query_scalar::<_, i64>(
                            "SELECT COUNT(*) FROM collaboration_sessions WHERE id = ? AND user_id = ?"
                        )
                        .bind(&evt.session_id)
                        .bind(&user_id)
                        .fetch_one(&db)
                        .await
                        .unwrap_or(0);

                        if is_owner > 0 {
                            last_seen_seq = last_seen_seq.max(evt.seq);
                            let data = json!({
                                "sessionId": evt.session_id,
                                "eventType": evt.event_type,
                                "payload": evt.payload
                            }).to_string();
                            yield Ok(Event::default()
                                .event("collaboration")
                                .id(super::broadcast::CollaborationBroadcaster::format_event_id(evt.seq))
                                .data(data));
                        }
                    }
                }
                Err(_) => break,
            }
        }
    };

    Sse::new(stream).keep_alive(KeepAlive::default())
}

/// 成熟度评估结果
struct ReadinessResult {
    can_admit: bool,
    reason: String,
}

/// 评估协同会话的成熟度，判断是否可以入场
fn evaluate_readiness(assignments: &[CollaborationAssignment]) -> ReadinessResult {
    if assignments.is_empty() {
        return ReadinessResult {
            can_admit: false,
            reason: "尚未分派协同任务，无法入场".to_string(),
        };
    }

    let incomplete = assignments
        .iter()
        .filter(|assignment| !matches!(assignment.status.as_str(), "ready" | "done"))
        .count();
    if incomplete > 0 {
        return ReadinessResult {
            can_admit: false,
            reason: format!("仍有 {} 个协同任务未完成，无法入场", incomplete),
        };
    }

    ReadinessResult {
        can_admit: true,
        reason: "关键依赖链无阻塞，编导确认入场".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::{
        dependencies_satisfied, CollaborationAssignment, COLLABORATION_PIPELINE_TYPE,
        COLLABORATION_TRIGGER_SOURCE,
    };

    fn assignment(agent_id: &str, status: &str, dependencies: &[&str]) -> CollaborationAssignment {
        CollaborationAssignment {
            id: format!("assignment-{agent_id}"),
            session_id: "session-1".to_string(),
            agent_id: agent_id.to_string(),
            task_type: "design".to_string(),
            goal: "test".to_string(),
            input_json: None,
            depends_on_json: (!dependencies.is_empty()).then(|| {
                serde_json::to_string(dependencies).expect("dependencies should serialize")
            }),
            status: status.to_string(),
            blocking_question_count: 0,
            last_question_fingerprint: None,
            ai_task_id: None,
            created_at: String::new(),
            updated_at: String::new(),
        }
    }

    #[test]
    fn collaboration_pipeline_type_matches_database_constraint() {
        let supported = [
            "one_click",
            "outline",
            "script",
            "storyboard",
            "review",
            "custom",
        ];
        let supported_trigger_sources = ["manual", "automation", "api", "retry"];

        assert!(supported.contains(&COLLABORATION_PIPELINE_TYPE));
        assert!(supported_trigger_sources.contains(&COLLABORATION_TRIGGER_SOURCE));
    }

    #[test]
    fn dependent_assignment_waits_for_upstream_completion() {
        let downstream = assignment("agent-b", "assigned", &["agent-a"]);
        let mut assignments = vec![assignment("agent-a", "running", &[]), downstream.clone()];
        assert!(!dependencies_satisfied(&downstream, &assignments));

        assignments[0].status = "done".to_string();
        assert!(dependencies_satisfied(&downstream, &assignments));
    }
}

/// 协同入场后自动创建 pipeline_run
const COLLABORATION_PIPELINE_TYPE: &str = "custom";
const COLLABORATION_TRIGGER_SOURCE: &str = "automation";

async fn create_pipeline_from_collaboration(
    state: &AppState,
    session: &CollaborationSession,
    assignments: &[CollaborationAssignment],
) -> Result<String, AppError> {
    let ready_assignments: Vec<&CollaborationAssignment> = assignments
        .iter()
        .filter(|a| a.status == "ready" || a.status == "done")
        .collect();

    if ready_assignments.is_empty() {
        return Err(AppError::BadRequest(
            "没有可创建工作区流程的协同任务".to_string(),
        ));
    }

    let step_keys = ready_assignments
        .iter()
        .map(|assignment| {
            (
                assignment.agent_id.clone(),
                format!("collab-{}", assignment.id),
            )
        })
        .collect::<std::collections::HashMap<_, _>>();
    let steps: Vec<crate::pipeline::model::CreatePipelineStepReq> = ready_assignments
        .iter()
        .enumerate()
        .map(|(i, a)| crate::pipeline::model::CreatePipelineStepReq {
            step_key: step_keys
                .get(&a.agent_id)
                .cloned()
                .unwrap_or_else(|| format!("collab-{}", a.id)),
            step_name: a.goal.clone(),
            step_order: i as i64,
            step_type: a.task_type.clone(),
            depends_on: a
                .depends_on_json
                .as_ref()
                .and_then(|v| serde_json::from_str::<Vec<String>>(v).ok())
                .unwrap_or_default()
                .into_iter()
                .filter_map(|agent_id| step_keys.get(&agent_id).cloned())
                .collect(),
            review_policy: None,
            max_retries: Some(3),
            prompt_template: Some(a.goal.clone()),
        })
        .collect();

    let req = crate::pipeline::model::CreatePipelineRunReq {
        project_id: session.project_id.clone(),
        conversation_id: session.conversation_id.clone(),
        pipeline_type: COLLABORATION_PIPELINE_TYPE.to_string(),
        trigger_source: COLLABORATION_TRIGGER_SOURCE.to_string(),
        beta_enabled: true,
        idempotency_key: Some(format!("collab-{}", session.id)),
        steps,
    };

    let (_, run) = crate::pipeline::handlers::create_pipeline_run_for_user(
        &state.db,
        &session.user_id,
        req,
        false,
    )
    .await?;
    let run_id = run.id;
    repo::update_session_pipeline_run_id(&state.db, &session.id, &run_id)
        .await
        .map_err(|error| AppError::Internal(error.to_string()))?;
    repo::update_session_state(
        &state.db,
        &session.id,
        SessionState::WorkspaceExecution.as_str(),
    )
    .await
    .map_err(|error| AppError::Internal(error.to_string()))?;
    tracing::info!(
        session_id = %session.id,
        pipeline_run_id = %run_id,
        "协同入场后自动创建 pipeline_run 成功"
    );
    let payload = json!({
        "sessionId": session.id,
        "pipelineRunId": run_id,
        "state": SessionState::WorkspaceExecution.as_str(),
    });
    let _ = repo::create_event(
        &state.db,
        &session.id,
        "collaboration_workspace_started",
        Some(&payload.to_string()),
    )
    .await;
    Ok(run_id)
}
