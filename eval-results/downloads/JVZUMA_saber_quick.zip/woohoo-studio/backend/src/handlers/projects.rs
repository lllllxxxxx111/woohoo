// Project handlers

use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use chrono::Utc;
use uuid::Uuid;

use crate::models::*;
use crate::AppState;

type ApiResult<T> = Result<Json<T>, (StatusCode, Json<serde_json::Value>)>;

fn error_response(status: StatusCode, msg: &str) -> (StatusCode, Json<serde_json::Value>) {
    (
        status,
        Json(serde_json::json!({ "error": msg })),
    )
}

pub async fn list_projects(
    State(state): State<AppState>,
) -> ApiResult<Vec<Project>> {
    let projects = sqlx::query_as::<_, Project>(
        "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects ORDER BY updated_at DESC"
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(projects))
}

pub async fn create_project(
    State(state): State<AppState>,
    Json(req): Json<CreateProjectRequest>,
) -> ApiResult<Project> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now();

    let project = Project {
        id: id.clone(),
        name: req.name,
        description: req.description,
        user_id: req.user_id,
        created_at: now,
        updated_at: now,
        settings: None,
    };

    sqlx::query(
        "INSERT INTO projects (id, name, description, user_id, created_at, updated_at, settings)
         VALUES (?, ?, ?, ?, ?, ?, ?)",
    )
    .bind(&project.id)
    .bind(&project.name)
    .bind(&project.description)
    .bind(&project.user_id)
    .bind(project.created_at.to_rfc3339())
    .bind(project.updated_at.to_rfc3339())
    .bind(None::<String>)
    .execute(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(project))
}

pub async fn get_project(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> ApiResult<ProjectWithRelated> {
    let project = sqlx::query_as::<_, Project>(
        "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects WHERE id = ?"
    )
    .bind(&id)
    .fetch_optional(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let project = match project {
        Some(p) => p,
        None => return Err(error_response(StatusCode::NOT_FOUND, "Project not found")),
    };

    let scripts = sqlx::query_as::<_, Script>(
        "SELECT id, project_id, scene_index, title, content, notes, created_at, updated_at FROM scripts WHERE project_id = ? ORDER BY scene_index"
    )
    .bind(&id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let storyboards = sqlx::query_as::<_, Storyboard>(
        "SELECT id, project_id, scene_id, order_idx, title, description, notes, created_at, updated_at FROM storyboards WHERE project_id = ? ORDER BY order_idx"
    )
    .bind(&id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let keyframes = sqlx::query_as::<_, Keyframe>(
        "SELECT id, project_id, storyboard_id, order_idx, image_url, prompt, parameters, notes, created_at FROM keyframes WHERE project_id = ? ORDER BY order_idx"
    )
    .bind(&id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let video_plans = sqlx::query_as::<_, VideoPlan>(
        "SELECT id, project_id, name, settings, timeline_json, created_at, updated_at FROM video_plans WHERE project_id = ?"
    )
    .bind(&id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let assets = sqlx::query_as::<_, Asset>(
        "SELECT id, project_id, name, asset_type, url, size_bytes, hash, mime_type, metadata, uploaded_at FROM assets WHERE project_id = ?"
    )
    .bind(&id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(ProjectWithRelated {
        project,
        scripts,
        storyboards,
        keyframes,
        video_plans,
        assets,
    }))
}

pub async fn update_project(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Json(req): Json<serde_json::Value>,
) -> ApiResult<Project> {
    let name = req.get("name").and_then(|v| v.as_str()).unwrap_or("");
    let description = req.get("description").and_then(|v| v.as_str()).map(|s| s.to_string());
    let now = Utc::now();

    sqlx::query(
        "UPDATE projects SET name = ?, description = ?, updated_at = ? WHERE id = ?",
    )
    .bind(name)
    .bind(&description)
    .bind(now.to_rfc3339())
    .bind(&id)
    .execute(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    let project = sqlx::query_as::<_, Project>(
        "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects WHERE id = ?"
    )
    .bind(&id)
    .fetch_one(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(project))
}

pub async fn delete_project(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> ApiResult<serde_json::Value> {
    sqlx::query("DELETE FROM projects WHERE id = ?")
        .bind(&id)
        .execute(&state.db)
        .await
        .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(serde_json::json!({ "deleted": true })))
}

pub async fn create_snapshot(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> ApiResult<ProjectSnapshot> {
    // Reuse get_project logic
    let Json(full) = get_project(State(state), Path(id.clone())).await?;

    Ok(Json(ProjectSnapshot {
        project: full.project,
        scripts: full.scripts,
        storyboards: full.storyboards,
        keyframes: full.keyframes,
        video_plans: full.video_plans,
        assets: full.assets,
        snapshot_at: Utc::now().to_rfc3339(),
        version: "1.0.0".to_string(),
    }))
}

// Tests
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_create_and_get_project() {
        // Basic in-memory integration test
        use crate::db;

        let pool = db::init_db("sqlite::memory:").await.expect("init db");
        let state = AppState { db: pool };

        // Create
        let create_req = CreateProjectRequest {
            name: "Test Project".to_string(),
            description: Some("A test".to_string()),
            user_id: "test-user".to_string(),
        };

        let Json(project) = create_project(
            State(state.clone()),
            Json(create_req),
        ).await.expect("create");

        assert_eq!(project.name, "Test Project");
        assert_eq!(project.user_id, "test-user");

        // Get
        let Json(fetched) = get_project(
            State(state),
            Path(project.id.clone()),
        ).await.expect("get");

        assert_eq!(fetched.project.id, project.id);
        assert_eq!(fetched.scripts.len(), 0);
    }
}
