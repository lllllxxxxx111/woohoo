// Export audit handlers - NEW FEATURE
// Records export events and provides history API

use axum::{
    extract::{Path, Query, State},
    http::StatusCode,
    Json,
};
use chrono::Utc;
use serde::Deserialize;
use uuid::Uuid;

use crate::db;
use crate::models::*;
use crate::AppState;

type ApiResult<T> = Result<Json<T>, (StatusCode, Json<serde_json::Value>)>;

fn error_response(status: StatusCode, msg: impl Into<String>) -> (StatusCode, Json<serde_json::Value>) {
    (status, Json(serde_json::json!({ "error": msg.into() })))
}

#[derive(Debug, Deserialize)]
pub struct ListQuery {
    pub limit: Option<i64>,
}

/// POST /api/exports/audit
/// Record a new export audit entry. Called by frontend after successful bundle generation.
///
/// Validates:
/// - manifest_hash must be 64 hex chars (SHA-256)
/// - project_id and user_id non-empty
/// - counts are non-negative
/// - export_type is either "full" or "core"
pub async fn record_export(
    State(state): State<AppState>,
    Json(req): Json<RecordExportRequest>,
) -> ApiResult<ExportAuditLog> {
    // Server-side validation
    let errors = req.validate();
    if !errors.is_empty() {
        return Err(error_response(
            StatusCode::BAD_REQUEST,
            format!("Validation errors: {}", errors.join("; ")),
        ));
    }

    // Verify project exists (foreign key integrity)
    let project_exists: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM projects WHERE id = ?",
    )
    .bind(&req.project_id)
    .fetch_one(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    if project_exists.0 == 0 {
        return Err(error_response(
            StatusCode::NOT_FOUND,
            format!("Project {} not found", req.project_id),
        ));
    }

    let id = Uuid::new_v4().to_string();
    let now = Utc::now();
    let export_type_str = req.export_type.to_string();

    db::insert_export_audit(
        &state.db,
        &id,
        &req.user_id,
        &req.project_id,
        &export_type_str,
        &req.manifest_hash,
        req.asset_count,
        req.missing_asset_count,
        req.file_count,
        req.total_size_bytes,
        req.blocking_issues_override.unwrap_or(false),
        &now.to_rfc3339(),
    )
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    // Fetch back to return complete record with correct timestamp
    let log = sqlx::query_as::<_, ExportAuditLog>(
        "SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                missing_asset_count, file_count, total_size_bytes,
                blocking_issues_override, created_at
         FROM export_audit_logs WHERE id = ?",
    )
    .bind(&id)
    .fetch_one(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    Ok(Json(log))
}

/// GET /api/projects/:id/exports
/// List export history for a specific project, newest first.
pub async fn list_project_exports(
    State(state): State<AppState>,
    Path(project_id): Path<String>,
) -> ApiResult<ExportListResponse> {
    // Verify project exists
    let project_exists: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM projects WHERE id = ?",
    )
    .bind(&project_id)
    .fetch_one(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    if project_exists.0 == 0 {
        return Err(error_response(StatusCode::NOT_FOUND, "Project not found"));
    }

    let exports = db::list_exports_by_project(&state.db, &project_id)
        .await
        .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    let total = exports.len() as i64;

    Ok(Json(ExportListResponse { exports, total }))
}

/// GET /api/exports/audit?limit=N
/// List recent exports across all projects (admin/auditor view).
pub async fn list_recent_exports(
    State(state): State<AppState>,
    Query(query): Query<ListQuery>,
) -> ApiResult<ExportListResponse> {
    let limit = query.limit.unwrap_or(20).clamp(1, 200);

    let exports = db::list_recent_exports(&state.db, limit)
        .await
        .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, format!("DB error: {e}")))?;

    let total = exports.len() as i64;

    Ok(Json(ExportListResponse { exports, total }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::db;
    use crate::models::CreateProjectRequest;

    async fn setup_test_state() -> AppState {
        let pool = db::init_db("sqlite::memory:").await.expect("init db");

        // Create a test project for foreign key checks
        let id = Uuid::new_v4().to_string();
        let now = Utc::now();
        sqlx::query(
            "INSERT INTO projects (id, name, description, user_id, created_at, updated_at, settings)
             VALUES (?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(&id)
        .bind("Test Project")
        .bind(Option::<String>::None)
        .bind("test-user")
        .bind(now.to_rfc3339())
        .bind(now.to_rfc3339())
        .bind(None::<String>)
        .execute(&pool)
        .await
        .expect("insert project");

        AppState { db: pool }
    }

    fn valid_request(project_id: &str) -> RecordExportRequest {
        RecordExportRequest {
            user_id: "test-user".to_string(),
            project_id: project_id.to_string(),
            export_type: ExportType::Full,
            manifest_hash: "a".repeat(64),
            asset_count: 5,
            missing_asset_count: 1,
            file_count: 12,
            total_size_bytes: Some(1024000),
            blocking_issues_override: Some(false),
        }
    }

    #[tokio::test]
    async fn test_record_export_success() {
        let state = setup_test_state().await;

        // Get the project ID
        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let req = valid_request(project_id);
        let Json(log) = record_export(State(state.clone()), Json(req))
            .await
            .expect("record export should succeed");

        assert_eq!(log.project_id, *project_id);
        assert_eq!(log.user_id, "test-user");
        assert_eq!(log.export_type, "full");
        assert_eq!(log.asset_count, 5);
        assert_eq!(log.missing_asset_count, 1);
        assert_eq!(log.file_count, 12);
        assert_eq!(log.manifest_hash.len(), 64);
    }

    #[tokio::test]
    async fn test_record_export_rejects_short_hash() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.manifest_hash = "tooshort".to_string();

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, msg) = result.err().unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
        let err_msg = msg.0.get("error").unwrap().as_str().unwrap();
        assert!(err_msg.contains("64-character hex"));
    }

    #[tokio::test]
    async fn test_record_export_rejects_non_hex_hash() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.manifest_hash = "g".repeat(64); // 'g' is not hex

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, _) = result.err().unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn test_record_export_rejects_nonexistent_project() {
        let state = setup_test_state().await;

        let mut req = valid_request("nonexistent-id-12345");
        req.project_id = "nonexistent-id-12345".to_string();

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, _) = result.err().unwrap();
        assert_eq!(status, StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn test_record_export_rejects_negative_counts() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.asset_count = -1;

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, _) = result.err().unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn test_list_project_exports() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        // Insert two exports
        for _ in 0..2 {
            let req = valid_request(project_id);
            record_export(State(state.clone()), Json(req)).await.expect("insert");
        }

        let Json(resp) = list_project_exports(State(state), Path(project_id.clone()))
            .await
            .expect("list");

        assert_eq!(resp.total, 2);
        assert_eq!(resp.exports.len(), 2);
        // Newest first
        assert!(resp.exports[0].created_at >= resp.exports[1].created_at);
    }

    #[tokio::test]
    async fn test_list_recent_exports_respects_limit() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        for _ in 0..5 {
            let req = valid_request(project_id);
            record_export(State(state.clone()), Json(req)).await.expect("insert");
        }

        let Json(resp) = list_recent_exports(
            State(state),
            Query(ListQuery { limit: Some(3) }),
        )
        .await
        .expect("list");

        assert_eq!(resp.exports.len(), 3);
        assert_eq!(resp.total, 3);
    }

    #[tokio::test]
    async fn test_core_export_type_accepted() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.export_type = ExportType::Core;

        let Json(log) = record_export(State(state), Json(req))
            .await
            .expect("core export");

        assert_eq!(log.export_type, "core");
    }

    #[tokio::test]
    async fn test_record_persists_all_required_fields() {
        // Verify that every required audit field (export type, project, user,
        // manifest hash, asset count, missing count, file count, timestamp)
        // is actually persisted and round-trips correctly.
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = projects[0].id.clone();

        let hash = "f".repeat(64);
        let req = RecordExportRequest {
            user_id: "audit-tester".to_string(),
            project_id: project_id.clone(),
            export_type: ExportType::Full,
            manifest_hash: hash.clone(),
            asset_count: 42,
            missing_asset_count: 3,
            file_count: 58,
            total_size_bytes: Some(9_999_999),
            blocking_issues_override: Some(true),
        };

        let Json(log) = record_export(State(state.clone()), Json(req))
            .await
            .expect("record");

        // Every required field must be present and correct
        assert!(!log.id.is_empty(), "id must be populated");
        assert_eq!(log.user_id, "audit-tester");
        assert_eq!(log.project_id, project_id);
        assert_eq!(log.export_type, "full");
        assert_eq!(log.manifest_hash, hash);
        assert_eq!(log.asset_count, 42);
        assert_eq!(log.missing_asset_count, 3);
        assert_eq!(log.file_count, 58);
        assert_eq!(log.total_size_bytes, Some(9_999_999));
        assert_eq!(log.blocking_issues_override, Some(true));
        // created_at must be a valid timestamp near now
        let now = Utc::now();
        assert!((log.created_at - now).num_seconds().abs() < 5, "created_at must be recent");

        // Also verify it shows up in list endpoint
        let Json(listing) = list_project_exports(State(state), Path(project_id))
            .await
            .expect("list");
        assert_eq!(listing.total, 1);
        assert_eq!(listing.exports[0].id, log.id);
        assert_eq!(listing.exports[0].manifest_hash, hash);
    }

    #[tokio::test]
    async fn test_rejects_empty_user_id() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.user_id = "".to_string();

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, msg) = result.err().unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(msg.0.get("error").unwrap().as_str().unwrap().contains("user_id"));
    }

    #[tokio::test]
    async fn test_rejects_file_count_zero() {
        let state = setup_test_state().await;

        let projects: Vec<Project> = sqlx::query_as::<_, Project>(
            "SELECT id, name, description, user_id, created_at, updated_at, settings FROM projects",
        )
        .fetch_all(&state.db)
        .await
        .expect("fetch projects");
        let project_id = &projects[0].id;

        let mut req = valid_request(project_id);
        req.file_count = 0;

        let result = record_export(State(state), Json(req)).await;
        assert!(result.is_err());
        let (status, _) = result.err().unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }
}
