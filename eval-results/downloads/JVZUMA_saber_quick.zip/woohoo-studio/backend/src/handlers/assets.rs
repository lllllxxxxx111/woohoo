// Asset handlers - simplified (stub upload/download for testing)

use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use chrono::Utc;
use uuid::Uuid;

use crate::models::*;
use crate::AppState;

type ApiResult<T> = Result<Json<T>, (StatusCode, Json<serde_json::Value>)>;

fn error_response(status: StatusCode, msg: &str) -> (StatusCode, Json<serde_json::Value>) {
    (status, Json(serde_json::json!({ "error": msg })))
}

pub async fn list_assets(
    State(state): State<AppState>,
    Path(project_id): Path<String>,
) -> ApiResult<Vec<Asset>> {
    let assets = sqlx::query_as::<_, Asset>(
        "SELECT id, project_id, name, asset_type, url, size_bytes, hash, mime_type, metadata, uploaded_at
         FROM assets WHERE project_id = ? ORDER BY uploaded_at DESC",
    )
    .bind(&project_id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &format!("DB error: {e}")))?;

    Ok(Json(assets))
}

pub async fn upload_asset(
    State(_state): State<AppState>,
) -> ApiResult<Asset> {
    // Simplified - real implementation would parse multipart
    let asset = Asset {
        id: Uuid::new_v4().to_string(),
        project_id: "stub".to_string(),
        name: "stub.bin".to_string(),
        asset_type: "other".to_string(),
        url: "/api/assets/stub/download".to_string(),
        size_bytes: None,
        hash: None,
        mime_type: None,
        metadata: None,
        uploaded_at: Utc::now(),
    };

    Ok(Json(asset))
}

pub async fn download_asset(
    State(_state): State<AppState>,
    Path(_id): Path<String>,
) -> StatusCode {
    // Stub - would serve file in production
    StatusCode::NOT_FOUND
}
