// Woohoo Studio Backend - Axum server with SQLite
mod db;
mod handlers;
mod models;

use axum::{
    routing::{get, post},
    Router,
};
use std::net::SocketAddr;
use tower_http::cors::{Any, CorsLayer};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

#[derive(Clone)]
pub struct AppState {
    pub db: sqlx::SqlitePool,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::registry()
        .with(tracing_subscriber::EnvFilter::new(
            std::env::var("RUST_LOG").unwrap_or_else(|_| "woohoo_studio_backend=info,tower_http=info".into()),
        ))
        .with(tracing_subscriber::fmt::layer())
        .init();

    // Initialize database
    let db_url = std::env::var("DATABASE_URL").unwrap_or_else(|_| "sqlite:woohoo.db".to_string());
    let pool = db::init_db(&db_url).await?;
    tracing::info!("Database initialized");

    let state = AppState { db: pool };

    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    let app = Router::new()
        // Project routes
        .route("/api/projects", get(handlers::projects::list_projects).post(handlers::projects::create_project))
        .route("/api/projects/:id", get(handlers::projects::get_project).put(handlers::projects::update_project).delete(handlers::projects::delete_project))
        .route("/api/projects/:id/snapshot", post(handlers::projects::create_snapshot))
        // Asset routes
        .route("/api/projects/:id/assets", get(handlers::assets::list_assets))
        .route("/api/assets/upload", post(handlers::assets::upload_asset))
        .route("/api/assets/:id/download", get(handlers::assets::download_asset))
        // NEW: Export audit routes
        .route("/api/projects/:id/exports", get(handlers::export_audit::list_project_exports))
        .route("/api/exports/audit", get(handlers::export_audit::list_recent_exports).post(handlers::export_audit::record_export))
        .layer(cors)
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], 3000));
    tracing::info!("Server listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
