// Data models

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

pub type Json = serde_json::Value;

// ---- Project ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Project {
    pub id: String,
    pub name: String,
    pub description: Option<String>,
    pub user_id: String,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub settings: Option<Json>,
}

#[derive(Debug, Deserialize)]
pub struct CreateProjectRequest {
    pub name: String,
    pub description: Option<String>,
    #[serde(default = "default_user_id")]
    pub user_id: String,
}

fn default_user_id() -> String {
    "anonymous".to_string()
}

// ---- Script ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Script {
    pub id: String,
    pub project_id: String,
    pub scene_index: i64,
    pub title: Option<String>,
    pub content: String,
    pub notes: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

// ---- Storyboard ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Storyboard {
    pub id: String,
    pub project_id: String,
    pub scene_id: Option<String>,
    pub order_idx: i64,
    pub title: Option<String>,
    pub description: Option<String>,
    pub notes: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

// ---- Keyframe ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Keyframe {
    pub id: String,
    pub project_id: String,
    pub storyboard_id: Option<String>,
    pub order_idx: i64,
    pub image_url: Option<String>,
    pub prompt: Option<String>,
    pub parameters: Option<Json>,
    pub notes: Option<String>,
    pub created_at: DateTime<Utc>,
}

// ---- VideoPlan ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct VideoPlan {
    pub id: String,
    pub project_id: String,
    pub name: Option<String>,
    pub settings: Option<Json>,
    pub timeline_json: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

// ---- Asset ----

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Asset {
    pub id: String,
    pub project_id: String,
    pub name: String,
    pub asset_type: String,
    pub url: String,
    pub size_bytes: Option<i64>,
    pub hash: Option<String>,
    pub mime_type: Option<String>,
    pub metadata: Option<Json>,
    pub uploaded_at: DateTime<Utc>,
}

// ---- Project with related data ----

#[derive(Debug, Serialize)]
pub struct ProjectWithRelated {
    #[serde(flatten)]
    pub project: Project,
    pub scripts: Vec<Script>,
    pub storyboards: Vec<Storyboard>,
    pub keyframes: Vec<Keyframe>,
    pub video_plans: Vec<VideoPlan>,
    pub assets: Vec<Asset>,
}

// ---- Project Snapshot ----

#[derive(Debug, Serialize)]
pub struct ProjectSnapshot {
    pub project: Project,
    pub scripts: Vec<Script>,
    pub storyboards: Vec<Storyboard>,
    pub keyframes: Vec<Keyframe>,
    pub video_plans: Vec<VideoPlan>,
    pub assets: Vec<Asset>,
    pub snapshot_at: String,
    pub version: String,
}

// ============================================================
// EXPORT AUDIT (NEW FEATURE)
// ============================================================

/// Export type: full bundle or core planning bundle
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum ExportType {
    Full,
    Core,
}

impl std::fmt::Display for ExportType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ExportType::Full => write!(f, "full"),
            ExportType::Core => write!(f, "core"),
        }
    }
}

/// An export audit log record stored in the database.
///
/// Design decision: We create a dedicated `export_audit_logs` table rather than
/// reusing a generic ops/action audit table because:
/// 1. Export audit entries have specific, typed fields (manifest_hash, asset_count, etc.)
///    that would be unstructured JSON in a generic audit table, losing queryability.
/// 2. Export records have different retention/query patterns than general action logs;
///    we want efficient queries by project_id with counts and hashes.
/// 3. We need to enforce referential integrity (project_id foreign key) and indexes
///    for fast history lookups without polluting a general audit table.
/// 4. PII/security: export manifests contain hashes that may require specific cleanup
///    policies separate from general operational logs.
#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct ExportAuditLog {
    /// Unique record ID (UUID v4)
    pub id: String,
    /// User who performed the export
    pub user_id: String,
    /// Project that was exported
    pub project_id: String,
    /// Type of export: "full" or "core"
    pub export_type: String,
    /// SHA-256 hash of manifest.json (hex-encoded, 64 chars)
    pub manifest_hash: String,
    /// Number of assets successfully packed into the bundle
    pub asset_count: i64,
    /// Number of assets that failed/missing
    pub missing_asset_count: i64,
    /// Total number of files in the bundle
    pub file_count: i64,
    /// Total size in bytes of the bundle
    pub total_size_bytes: Option<i64>,
    /// Whether user chose to proceed despite blocking preflight issues
    pub blocking_issues_override: Option<bool>,
    /// When the export occurred
    pub created_at: DateTime<Utc>,
}

<[PLHD77_never_used_51bce0c785ca2f68081bfa7d91973934]>
/// Request body for recording an export audit entry.
/// Called by the frontend after successfully generating an export bundle.
#[derive(Debug, Deserialize)]
pub struct RecordExportRequest {
    pub user_id: String,
    pub project_id: String,
    pub export_type: ExportType,
    /// Must be exactly 64 hex characters (SHA-256)
    pub manifest_hash: String,
    pub asset_count: i64,
    pub missing_asset_count: i64,
    pub file_count: i64,
    pub total_size_bytes: Option<i64>,
    pub blocking_issues_override: Option<bool>,
}

impl RecordExportRequest {
    /// Validate the request. Returns Vec of error messages (empty = valid).
    pub fn validate(&self) -> Vec<String> {
        let mut errors = Vec::new();
        if self.user_id.trim().is_empty() {
            errors.push("user_id is required".to_string());
        }
        if self.project_id.trim().is_empty() {
            errors.push("project_id is required".to_string());
        }
        // manifest_hash must be 64 hex chars
        if self.manifest_hash.len() != 64 || !self.manifest_hash.chars().all(|c| c.is_ascii_hexdigit()) {
            errors.push("manifest_hash must be a 64-character hex string (SHA-256)".to_string());
        }
        if self.asset_count < 0 {
            errors.push("asset_count must be non-negative".to_string());
        }
        if self.missing_asset_count < 0 {
            errors.push("missing_asset_count must be non-negative".to_string());
        }
        if self.file_count < 1 {
            errors.push("file_count must be at least 1".to_string());
        }
        if let Some(size) = self.total_size_bytes {
            if size < 0 {
                errors.push("total_size_bytes must be non-negative".to_string());
            }
        }
        errors
    }
}

#[derive(Debug, Serialize)]
pub struct ExportListResponse {
    pub exports: Vec<ExportAuditLog>,
    pub total: i64,
}
