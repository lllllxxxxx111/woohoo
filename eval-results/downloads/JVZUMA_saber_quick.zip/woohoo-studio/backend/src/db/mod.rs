// Database initialization, migrations, and queries

use sqlx::{sqlite::SqlitePoolOptions, SqlitePool};
use anyhow::Result;

pub async fn init_db(database_url: &str) -> Result<SqlitePool> {
    let pool = SqlitePoolOptions::new()
        .max_connections(5)
        .connect(database_url)
        .await?;

    // Run migrations
    run_migrations(&pool).await?;

    Ok(pool)
}

async fn run_migrations(pool: &SqlitePool) -> Result<()> {
    // Create projects table
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            settings TEXT
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS scripts (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            scene_index INTEGER NOT NULL,
            title TEXT,
            content TEXT NOT NULL DEFAULT '',
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS storyboards (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            scene_id TEXT,
            order_idx INTEGER NOT NULL DEFAULT 0,
            title TEXT,
            description TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS keyframes (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            storyboard_id TEXT,
            order_idx INTEGER NOT NULL DEFAULT 0,
            image_url TEXT,
            prompt TEXT,
            parameters TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS video_plans (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            name TEXT,
            settings TEXT,
            timeline_json TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS assets (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            name TEXT NOT NULL,
            asset_type TEXT NOT NULL DEFAULT 'other',
            url TEXT NOT NULL,
            size_bytes INTEGER,
            hash TEXT,
            mime_type TEXT,
            metadata TEXT,
            uploaded_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    // =====================================================
    // NEW: export_audit_logs table for delivery audit trail
    // =====================================================
    //
    // Design rationale (see models/mod.rs ExportAuditLog doc comment):
    // - Dedicated table instead of generic ops_audit because export records have
    //   typed, queryable fields (manifest_hash, counts, sizes).
    // - Indexed on project_id and created_at for fast history queries.
    // - manifest_hash has uniqueness enforced per (project_id, hash) to detect
    //   duplicate exports of the same content.
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS export_audit_logs (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            export_type TEXT NOT NULL CHECK(export_type IN ('full', 'core')),
            manifest_hash TEXT NOT NULL,
            asset_count INTEGER NOT NULL DEFAULT 0,
            missing_asset_count INTEGER NOT NULL DEFAULT 0,
            file_count INTEGER NOT NULL DEFAULT 0,
            total_size_bytes INTEGER,
            blocking_issues_override INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )",
    )
    .execute(pool)
    .await?;

    // Indexes for fast lookup
    sqlx::query(
        "CREATE INDEX IF NOT EXISTS idx_export_audit_project_id ON export_audit_logs(project_id)",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE INDEX IF NOT EXISTS idx_export_audit_created_at ON export_audit_logs(created_at DESC)",
    )
    .execute(pool)
    .await?;

    sqlx::query(
        "CREATE INDEX IF NOT EXISTS idx_export_audit_user_id ON export_audit_logs(user_id)",
    )
    .execute(pool)
    .await?;

    Ok(())
}

// ---- Export audit queries ----

pub async fn insert_export_audit(
    pool: &SqlitePool,
    id: &str,
    user_id: &str,
    project_id: &str,
    export_type: &str,
    manifest_hash: &str,
    asset_count: i64,
    missing_asset_count: i64,
    file_count: i64,
    total_size_bytes: Option<i64>,
    blocking_override: bool,
    created_at: &str,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO export_audit_logs
            (id, user_id, project_id, export_type, manifest_hash, asset_count,
             missing_asset_count, file_count, total_size_bytes, blocking_issues_override, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    )
    .bind(id)
    .bind(user_id)
    .bind(project_id)
    .bind(export_type)
    .bind(manifest_hash)
    .bind(asset_count)
    .bind(missing_asset_count)
    .bind(file_count)
    .bind(total_size_bytes)
    .bind(blocking_override as i64)
    .bind(created_at)
    .execute(pool)
    .await?;

    Ok(())
}

pub async fn list_exports_by_project(pool: &SqlitePool, project_id: &str) -> Result<Vec<super::models::ExportAuditLog>> {
    let rows = sqlx::query_as::<_, super::models::ExportAuditLog>(
        "SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                missing_asset_count, file_count, total_size_bytes,
                blocking_issues_override, created_at
         FROM export_audit_logs
         WHERE project_id = ?
         ORDER BY created_at DESC",
    )
    .bind(project_id)
    .fetch_all(pool)
    .await?;

    Ok(rows)
}

pub async fn list_recent_exports(pool: &SqlitePool, limit: i64) -> Result<Vec<super::models::ExportAuditLog>> {
    let rows = sqlx::query_as::<_, super::models::ExportAuditLog>(
        "SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                missing_asset_count, file_count, total_size_bytes,
                blocking_issues_override, created_at
         FROM export_audit_logs
         ORDER BY created_at DESC
         LIMIT ?",
    )
    .bind(limit)
    .fetch_all(pool)
    .await?;

    Ok(rows)
}

pub async fn count_exports_by_project(pool: &SqlitePool, project_id: &str) -> Result<i64> {
    let row: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM export_audit_logs WHERE project_id = ?",
    )
    .bind(project_id)
    .fetch_one(pool)
    .await?;

    Ok(row.0)
}
