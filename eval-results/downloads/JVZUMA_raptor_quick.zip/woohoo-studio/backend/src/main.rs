// Woohoo Studio Backend - Rust Axum server
use axum::routing::{get, post};
use axum::{Json, Router};
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::SqlitePool;
use std::net::SocketAddr;
use tower_http::cors::CorsLayer;
use tower_http::trace::TraceLayer;
use woohoo_studio_backend::{handlers, AppState};

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    // Initialize database
    let db_url = std::env::var("DATABASE_URL").unwrap_or_else(|_| "sqlite:woohoo.db".to_string());
    let pool = init_database(&db_url).await;

    let state = AppState { db: pool };

    // Build router
    let app = Router::new()
        // Project routes (minimal stubs for existing endpoints)
        .route("/api/projects", get(list_projects).post(create_project_stub))
        .route("/api/projects/:id", get(get_project_stub))
        .route("/api/projects/:id/scripts", get(get_scripts_stub))
        .route("/api/projects/:id/storyboards", get(get_storyboards_stub))
        .route("/api/projects/:id/keyframes", get(get_keyframes_stub))
        .route("/api/projects/:id/video-plans", get(get_video_plans_stub))
        .route("/api/projects/:id/assets", get(get_assets_stub))
        .route("/api/projects/:id/sessions", get(get_sessions_stub))
        // Export audit routes
        .route("/api/projects/:id/exports", get(handlers::exports::list_project_exports))
        .route("/api/projects/:id/exports/count", get(handlers::exports::count_project_exports))
        .route("/api/exports/audit", get(handlers::exports::list_exports).post(handlers::exports::record_export))
        .route("/api/exports/audit/:id", get(handlers::exports::get_export_audit))
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], 3001));
    tracing::info!("Woohoo Studio backend listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn init_database(db_url: &str) -> SqlitePool {
    let options = SqliteConnectOptions::new()
        .filename(db_url.strip_prefix("sqlite:").unwrap_or(db_url))
        .create_if_missing(true);

    let pool = SqlitePoolOptions::new()
        .max_connections(5)
        .connect_with(options)
        .await
        .expect("Failed to connect to database");

    // Run migrations
    let migration_sql = include_str!("../migrations/001_init.sql");
    sqlx::query(migration_sql)
        .execute(&pool)
        .await
        .expect("Failed to run initial migration");

    tracing::info!("Database initialized successfully");
    pool
}

// --- Stub handlers for existing endpoints (return empty arrays for bootstrapping) ---

async fn list_projects() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn create_project_stub(Json(_body): Json<serde_json::Value>) -> Json<serde_json::Value> {
    Json(serde_json::json!({"id": "stub", "name": "Stub Project"}))
}

async fn get_project_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!({"id": "stub", "name": "Stub Project"}))
}

async fn get_scripts_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn get_storyboards_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn get_keyframes_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn get_video_plans_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn get_assets_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}

async fn get_sessions_stub() -> Json<serde_json::Value> {
    Json(serde_json::json!([]))
}
