// Export audit model and database operations
use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::sqlite::SqliteArguments;
use sqlx::{Arguments, SqlitePool};
use uuid::Uuid;

/// Export audit record as stored in the database
#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
#[serde(rename_all = "camelCase")]
#[sqlx(rename_all = "snake_case")]
pub struct ExportAuditRecord {
    pub id: String,
    pub user_id: String,
    pub project_id: String,
    pub export_type: String,
    pub manifest_hash: String,
    pub asset_count: i64,
    pub missing_asset_count: i64,
    pub total_size_bytes: i64,
    pub created_at: String,
}

/// Request body for creating an export audit record
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateExportAuditRequest {
    pub project_id: String,
    pub export_type: String,
    pub manifest_hash: String,
    pub asset_count: i64,
    pub missing_asset_count: i64,
    pub total_size_bytes: i64,
}

/// Valid export types
const VALID_EXPORT_TYPES: &[&str] = &["full", "core", "snapshot"];

impl CreateExportAuditRequest {
    pub fn validate(&self) -> Result<(), Vec<String>> {
        let mut errors = Vec::new();

        if self.project_id.is_empty() {
            errors.push("project_id is required".to_string());
        }
        if !VALID_EXPORT_TYPES.contains(&self.export_type.as_str()) {
            errors.push(format!(
                "export_type must be one of: {}",
                VALID_EXPORT_TYPES.join(", ")
            ));
        }
        if self.manifest_hash.is_empty() {
            errors.push("manifest_hash is required".to_string());
        }
        if self.asset_count < 0 {
            errors.push("asset_count must be non-negative".to_string());
        }
        if self.missing_asset_count < 0 {
            errors.push("missing_asset_count must be non-negative".to_string());
        }
        if self.total_size_bytes < 0 {
            errors.push("total_size_bytes must be non-negative".to_string());
        }
        // manifest_hash should be a valid hex SHA-256 (64 hex chars)
        if self.manifest_hash.len() != 64 {
            errors.push("manifest_hash must be a 64-character hex string (SHA-256)".to_string());
        }
        if !self.manifest_hash.chars().all(|c| c.is_ascii_hexdigit()) {
            errors.push("manifest_hash must contain only hexadecimal characters".to_string());
        }

        if errors.is_empty() {
            Ok(())
        } else {
            Err(errors)
        }
    }
}

/// Create a new export audit record in the database
pub async fn create_export_audit(
    pool: &SqlitePool,
    user_id: &str,
    req: &CreateExportAuditRequest,
) -> Result<ExportAuditRecord, sqlx::Error> {
    let id = Uuid::new_v4().to_string();
    let created_at = Utc::now().to_rfc3339();

    sqlx::query(
        r#"INSERT INTO export_audit_logs (id, user_id, project_id, export_type, manifest_hash, asset_count, missing_asset_count, total_size_bytes, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"#,
    )
    .bind(&id)
    .bind(user_id)
    .bind(&req.project_id)
    .bind(&req.export_type)
    .bind(&req.manifest_hash)
    .bind(req.asset_count)
    .bind(req.missing_asset_count)
    .bind(req.total_size_bytes)
    .bind(&created_at)
    .execute(pool)
    .await?;

    Ok(ExportAuditRecord {
        id,
        user_id: user_id.to_string(),
        project_id: req.project_id.clone(),
        export_type: req.export_type.clone(),
        manifest_hash: req.manifest_hash.clone(),
        asset_count: req.asset_count,
        missing_asset_count: req.missing_asset_count,
        total_size_bytes: req.total_size_bytes,
        created_at,
    })
}

/// List export audit records for a project, newest first
pub async fn list_export_audits_by_project(
    pool: &SqlitePool,
    project_id: &str,
    limit: Option<i64>,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    let limit = limit.unwrap_or(50);
    let records = sqlx::query_as::<_, ExportAuditRecord>(
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, created_at
           FROM export_audit_logs
           WHERE project_id = ?
           ORDER BY created_at DESC
           LIMIT ?"#,
    )
    .bind(project_id)
    .bind(limit)
    .fetch_all(pool)
    .await?;

    Ok(records)
}

/// Get a single export audit record by ID
pub async fn get_export_audit_by_id(
    pool: &SqlitePool,
    id: &str,
) -> Result<Option<ExportAuditRecord>, sqlx::Error> {
    let record = sqlx::query_as::<_, ExportAuditRecord>(
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, created_at
           FROM export_audit_logs
           WHERE id = ?"#,
    )
    .bind(id)
    .fetch_optional(pool)
    .await?;

    Ok(record)
}

/// Count total exports for a project
pub async fn count_export_audits_by_project(
    pool: &SqlitePool,
    project_id: &str,
) -> Result<i64, sqlx::Error> {
    let count: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM export_audit_logs WHERE project_id = ?",
    )
    .bind(project_id)
    .fetch_one(pool)
    .await?;

    Ok(count.0)
}

/// List export audit records with optional filters (project_id, user_id, export_type),
/// newest first, up to `limit` rows. Pass `None` for a filter to skip it.
pub async fn list_export_audits(
    pool: &SqlitePool,
    project_id: Option<&str>,
    user_id: Option<&str>,
    export_type: Option<&str>,
    limit: i64,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    // Build dynamic WHERE clause. We always have a true base clause so we can
    // unconditionally append `AND ...` predicates.
    let mut sql = String::from(
        "SELECT id, user_id, project_id, export_type, manifest_hash, asset_count, \
                missing_asset_count, total_size_bytes, created_at \
         FROM export_audit_logs WHERE 1=1",
    );
    // Collect bound arguments into a SqliteArguments so we don't hit the
    // "each .bind() changes the query type" footgun in sqlx 0.7.
    let mut args: SqliteArguments<'_> = SqliteArguments::default();
    if let Some(pid) = project_id {
        sql.push_str(" AND project_id = ?");
        args.add(pid).map_err(sqlx::Error::Encode)?;
    }
    if let Some(uid) = user_id {
        sql.push_str(" AND user_id = ?");
        args.add(uid).map_err(sqlx::Error::Encode)?;
    }
    if let Some(et) = export_type {
        sql.push_str(" AND export_type = ?");
        args.add(et).map_err(sqlx::Error::Encode)?;
    }
    sql.push_str(" ORDER BY created_at DESC LIMIT ?");
    args.add(limit).map_err(sqlx::Error::Encode)?;

    sqlx::query_as_with::<_, ExportAuditRecord, _>(&sql, args)
        .fetch_all(pool)
        .await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_validate_valid_request() {
        let req = CreateExportAuditRequest {
            project_id: "proj-123".to_string(),
            export_type: "full".to_string(),
            manifest_hash: "a".repeat(64),
            asset_count: 10,
            missing_asset_count: 2,
            total_size_bytes: 1024000,
        };
        assert!(req.validate().is_ok());
    }

    #[test]
    fn test_validate_empty_project_id() {
        let req = CreateExportAuditRequest {
            project_id: "".to_string(),
            export_type: "full".to_string(),
            manifest_hash: "a".repeat(64),
            asset_count: 0,
            missing_asset_count: 0,
            total_size_bytes: 0,
        };
        let errors = req.validate().unwrap_err();
        assert!(errors.iter().any(|e| e.contains("project_id")));
    }

    #[test]
    fn test_validate_invalid_export_type() {
        let req = CreateExportAuditRequest {
            project_id: "proj-123".to_string(),
            export_type: "invalid".to_string(),
            manifest_hash: "a".repeat(64),
            asset_count: 0,
            missing_asset_count: 0,
            total_size_bytes: 0,
        };
        let errors = req.validate().unwrap_err();
        assert!(errors.iter().any(|e| e.contains("export_type")));
    }

    #[test]
    fn test_validate_short_manifest_hash() {
        let req = CreateExportAuditRequest {
            project_id: "proj-123".to_string(),
            export_type: "full".to_string(),
            manifest_hash: "abc123".to_string(),
            asset_count: 0,
            missing_asset_count: 0,
            total_size_bytes: 0,
        };
        let errors = req.validate().unwrap_err();
        assert!(errors.iter().any(|e| e.contains("64-character")));
    }

    #[test]
    fn test_validate_non_hex_manifest_hash() {
        let mut hash = "g".repeat(64); // 'g' is not hex
        let req = CreateExportAuditRequest {
            project_id: "proj-123".to_string(),
            export_type: "full".to_string(),
            manifest_hash: std::mem::take(&mut hash),
            asset_count: 0,
            missing_asset_count: 0,
            total_size_bytes: 0,
        };
        let errors = req.validate().unwrap_err();
        assert!(errors.iter().any(|e| e.contains("hexadecimal")));
    }

    #[test]
    fn test_validate_negative_counts() {
        let req = CreateExportAuditRequest {
            project_id: "proj-123".to_string(),
            export_type: "core".to_string(),
            manifest_hash: "a".repeat(64),
            asset_count: -1,
            missing_asset_count: -1,
            total_size_bytes: -100,
        };
        let errors = req.validate().unwrap_err();
        assert!(errors.iter().any(|e| e.contains("asset_count")));
        assert!(errors.iter().any(|e| e.contains("missing_asset_count")));
        assert!(errors.iter().any(|e| e.contains("total_size_bytes")));
    }

    #[test]
    fn test_validate_all_export_types() {
        for t in &["full", "core", "snapshot"] {
            let req = CreateExportAuditRequest {
                project_id: "proj-123".to_string(),
                export_type: t.to_string(),
                manifest_hash: "a".repeat(64),
                asset_count: 0,
                missing_asset_count: 0,
                total_size_bytes: 0,
            };
            assert!(req.validate().is_ok(), "export_type '{}' should be valid", t);
        }
    }
}
