//! Woohoo Studio backend library crate.
//!
//! Exposes AppState, handlers, and models so that integration tests under /tests
//! can drive the Axum router in-process.

pub mod handlers;
pub mod models;

use sqlx::SqlitePool;

#[derive(Clone)]
pub struct AppState {
    pub db: SqlitePool,
}
