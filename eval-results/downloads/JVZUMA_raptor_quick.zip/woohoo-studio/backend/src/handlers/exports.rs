// Export audit HTTP handlers
//
// Endpoints:
//   POST /api/exports/audit                  Record a new export event (called by frontend after export).
//   GET  /api/exports/audit/:id              Fetch a single audit record by id.
//   GET  /api/exports/audit                  Global listing (paginated, newest first) with optional
//                                           ?project_id=<id>, ?user_id=<id>, ?export_type=<t>, ?limit=N.
//   GET  /api/projects/:id/exports           List exports for a project (newest first, ?limit=N).
//   GET  /api/projects/:id/exports/count     Count exports for a project.
//
// Authentication / identity:
//   In production, user identity comes from an auth middleware (JWT / session). Until that's wired up
//   the handler looks for an `X-User-Id` header and falls back to `"anonymous"`; this is logged so we
//   know which exports are un-attributed.

use axum::extract::{Path, Query, State};
use axum::http::StatusCode;
use axum::response::Json;
use axum::http::HeaderMap;
use serde::Deserialize;
use sqlx::SqlitePool;

use crate::models::export_audit::{
    count_export_audits_by_project, create_export_audit, get_export_audit_by_id,
    list_export_audits_by_project, list_export_audits, CreateExportAuditRequest, ExportAuditRecord,
};
use crate::AppState;

const DEFAULT_USER_ID: &str = "anonymous";
const DEFAULT_LIMIT: i64 = 50;
const MAX_LIMIT: i64 = 200;

#[derive(Debug, Deserialize)]
pub struct ListQuery {
    pub limit: Option<i64>,
}

#[derive(Debug, Deserialize)]
pub struct GlobalListQuery {
    pub project_id: Option<String>,
    pub user_id: Option<String>,
    pub export_type: Option<String>,
    pub limit: Option<i64>,
}

type ApiResponse<T> = Result<Json<T>, (StatusCode, Json<serde_json::Value>)>;

fn error_response(status: StatusCode, message: &str) -> (StatusCode, Json<serde_json::Value>) {
    (status, Json(serde_json::json!({ "error": message })))
}

fn extract_user_id(headers: &HeaderMap) -> String {
    headers
        .get("x-user-id")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| DEFAULT_USER_ID.to_string())
}

fn parse_limit(limit: Option<i64>) -> Result<i64, (StatusCode, Json<serde_json::Value>)> {
    let limit = limit.unwrap_or(DEFAULT_LIMIT);
    if limit < 1 || limit > MAX_LIMIT {
        return Err(error_response(
            StatusCode::BAD_REQUEST,
            &format!("limit must be between 1 and {MAX_LIMIT}"),
        ));
    }
    Ok(limit)
}

async fn project_exists(db: &SqlitePool, project_id: &str) -> Result<bool, sqlx::Error> {
    let (count,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM projects WHERE id = ?")
        .bind(project_id)
        .fetch_one(db)
        .await?;
    Ok(count > 0)
}

/// POST /api/exports/audit
/// Record a new export audit entry.
pub async fn record_export(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<CreateExportAuditRequest>,
) -> ApiResponse<ExportAuditRecord> {
    if let Err(errors) = req.validate() {
        return Err(error_response(
            StatusCode::BAD_REQUEST,
            &format!("Validation failed: {}", errors.join("; ")),
        ));
    }

    let exists = project_exists(&state.db, &req.project_id)
        .await
        .unwrap_or(false);
    if !exists {
        return Err(error_response(StatusCode::NOT_FOUND, "Project not found"));
    }

    let user_id = extract_user_id(&headers);

    match create_export_audit(&state.db, &user_id, &req).await {
        Ok(record) => {
            tracing::info!(
                audit_id = %record.id,
                project_id = %record.project_id,
                user_id = %record.user_id,
                export_type = %record.export_type,
                asset_count = record.asset_count,
                missing = record.missing_asset_count,
                "recorded export audit"
            );
            Ok(Json(record))
        }
        Err(e) => {
            tracing::error!(error = %e, "failed to create export audit");
            Err(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Failed to record export",
            ))
        }
    }
}

/// GET /api/exports/audit/:id
pub async fn get_export_audit(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> ApiResponse<ExportAuditRecord> {
    if id.is_empty() {
        return Err(error_response(StatusCode::BAD_REQUEST, "id is required"));
    }
    match get_export_audit_by_id(&state.db, &id).await {
        Ok(Some(record)) => Ok(Json(record)),
        Ok(None) => Err(error_response(StatusCode::NOT_FOUND, "Export record not found")),
        Err(e) => {
            tracing::error!(error = %e, "failed to fetch export audit");
            Err(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Failed to get export record",
            ))
        }
    }
}

/// GET /api/projects/:id/exports
pub async fn list_project_exports(
    State(state): State<AppState>,
    Path(project_id): Path<String>,
    Query(query): Query<ListQuery>,
) -> ApiResponse<Vec<ExportAuditRecord>> {
    if project_id.is_empty() {
        return Err(error_response(StatusCode::BAD_REQUEST, "project_id is required"));
    }
    let limit = parse_limit(query.limit)?;

    let exists = project_exists(&state.db, &project_id)
        .await
        .unwrap_or(false);
    if !exists {
        return Err(error_response(StatusCode::NOT_FOUND, "Project not found"));
    }

    match list_export_audits_by_project(&state.db, &project_id, Some(limit)).await {
        Ok(records) => Ok(Json(records)),
        Err(e) => {
            tracing::error!(error = %e, "failed to list export audits");
            Err(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Failed to list exports",
            ))
        }
    }
}

/// GET /api/projects/:id/exports/count
pub async fn count_project_exports(
    State(state): State<AppState>,
    Path(project_id): Path<String>,
) -> ApiResponse<serde_json::Value> {
    if project_id.is_empty() {
        return Err(error_response(StatusCode::BAD_REQUEST, "project_id is required"));
    }
    match count_export_audits_by_project(&state.db, &project_id).await {
        Ok(count) => Ok(Json(serde_json::json!({ "count": count }))),
        Err(e) => {
            tracing::error!(error = %e, "failed to count export audits");
            Err(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Failed to count exports",
            ))
        }
    }
}

/// GET /api/exports/audit
/// Global list endpoint — supports optional filters for project_id / user_id / export_type.
pub async fn list_exports(
    State(state): State<AppState>,
    Query(query): Query<GlobalListQuery>,
) -> ApiResponse<Vec<ExportAuditRecord>> {
    let limit = parse_limit(query.limit)?;

    if let Some(et) = &query.export_type {
        if !["full", "core", "snapshot"].contains(&et.as_str()) {
            return Err(error_response(
                StatusCode::BAD_REQUEST,
                "export_type must be one of: full, core, snapshot",
            ));
        }
    }

    match list_export_audits(&state.db, query.project_id.as_deref(), query.user_id.as_deref(), query.export_type.as_deref(), limit).await {
        Ok(records) => Ok(Json(records)),
        Err(e) => {
            tracing::error!(error = %e, "failed to list export audits globally");
            Err(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Failed to list exports",
            ))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_limit_default() {
        assert_eq!(parse_limit(None).unwrap(), DEFAULT_LIMIT);
    }

    #[test]
    fn test_parse_limit_bounds() {
        assert!(parse_limit(Some(0)).is_err());
        assert!(parse_limit(Some(-5)).is_err());
        assert!(parse_limit(Some(MAX_LIMIT + 1)).is_err());
        assert_eq!(parse_limit(Some(1)).unwrap(), 1);
        assert_eq!(parse_limit(Some(MAX_LIMIT)).unwrap(), MAX_LIMIT);
    }

    #[test]
    fn test_error_response_shape() {
        let (status, body) = error_response(StatusCode::BAD_REQUEST, "bad");
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(body.0["error"], "bad");
    }

    #[test]
    fn test_extract_user_id_prefers_header() {
        let mut headers = HeaderMap::new();
        headers.insert("x-user-id", "alice".parse().unwrap());
        assert_eq!(extract_user_id(&headers), "alice");
    }

    #[test]
    fn test_extract_user_id_falls_back_to_anonymous() {
        let headers = HeaderMap::new();
        assert_eq!(extract_user_id(&headers), DEFAULT_USER_ID);
    }

    #[test]
    fn test_extract_user_id_ignores_empty() {
        let mut headers = HeaderMap::new();
        headers.insert("x-user-id", "   ".parse().unwrap());
        assert_eq!(extract_user_id(&headers), DEFAULT_USER_ID);
    }
}
