//! Integration tests for export-audit database operations and HTTP handlers.
//!
//! These tests spin up an in-memory SQLite database, run the migration, seed a
//! project, and exercise the CRUD paths end-to-end against the Axum router.

use axum::body::Body;
use axum::http::{Request, StatusCode};
use axum::Router;
use http_body_util::BodyExt;
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::SqlitePool;
use std::str::FromStr;
use tower::ServiceExt;

use woohoo_studio_backend::handlers::exports as export_handlers;
use woohoo_studio_backend::models::export_audit::{
    count_export_audits_by_project, create_export_audit, get_export_audit_by_id, list_export_audits,
    list_export_audits_by_project, CreateExportAuditRequest,
};
use woohoo_studio_backend::AppState;

const MIGRATION_SQL: &str = include_str!("../../migrations/001_init.sql");

async fn setup_db() -> SqlitePool {
    let options = SqliteConnectOptions::from_str("sqlite::memory:").unwrap();
    let pool = SqlitePoolOptions::new()
        .max_connections(1)
        .connect_with(options)
        .await
        .expect("connect to in-memory db");
    sqlx::query(MIGRATION_SQL)
        .execute(&pool)
        .await
        .expect("run migration");
    sqlx::query("INSERT INTO projects (id, name, owner_id) VALUES (?, ?, ?)")
        .bind("proj-1")
        .bind("Demo Project")
        .bind("user-1")
        .execute(&pool)
        .await
        .expect("seed project");
    pool
}

fn app(pool: SqlitePool) -> Router {
    Router::new()
        .route(
            "/api/exports/audit",
            axum::routing::get(export_handlers::list_exports)
                .post(export_handlers::record_export),
        )
        .route(
            "/api/exports/audit/:id",
            axum::routing::get(export_handlers::get_export_audit),
        )
        .route(
            "/api/projects/:id/exports",
            axum::routing::get(export_handlers::list_project_exports),
        )
        .route(
            "/api/projects/:id/exports/count",
            axum::routing::get(export_handlers::count_project_exports),
        )
        .with_state(AppState { db: pool })
}

fn valid_hash() -> String {
    "a".repeat(64)
}

fn valid_request() -> CreateExportAuditRequest {
    CreateExportAuditRequest {
        project_id: "proj-1".to_string(),
        export_type: "full".to_string(),
        manifest_hash: valid_hash(),
        asset_count: 5,
        missing_asset_count: 1,
        total_size_bytes: 1024,
    }
}

async fn read_json(resp: axum::http::Response<Body>) -> serde_json::Value {
    let bytes = resp
        .into_body()
        .collect()
        .await
        .unwrap()
        .to_bytes();
    serde_json::from_slice(&bytes).unwrap()
}

// ---------------- DB ops tests ----------------

#[tokio::test]
async fn create_and_get_audit_roundtrip() {
    let pool = setup_db().await;
    let req = valid_request();
    let rec = create_export_audit(&pool, "user-1", &req).await.unwrap();
    assert_eq!(rec.project_id, "proj-1");
    assert_eq!(rec.user_id, "user-1");
    assert_eq!(rec.export_type, "full");
    assert_eq!(rec.asset_count, 5);
    assert_eq!(rec.missing_asset_count, 1);
    assert_eq!(rec.total_size_bytes, 1024);
    assert_eq!(rec.manifest_hash.len(), 64);
    assert!(!rec.id.is_empty());
    assert!(!rec.created_at.is_empty());

    let fetched = get_export_audit_by_id(&pool, &rec.id).await.unwrap().unwrap();
    assert_eq!(fetched.id, rec.id);
}

#[tokio::test]
async fn list_by_project_orders_newest_first() {
    let pool = setup_db().await;
    let first = create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    let mut req = valid_request();
    req.manifest_hash = "b".repeat(64);
    let newer = create_export_audit(&pool, "u1", &req).await.unwrap();

    let list = list_export_audits_by_project(&pool, "proj-1", Some(50)).await.unwrap();
    assert_eq!(list.len(), 2);
    assert_eq!(list[0].id, newer.id); // newest first
    assert_eq!(list[1].id, first.id);
}

#[tokio::test]
async fn list_respects_limit() {
    let pool = setup_db().await;
    for i in 0..5 {
        let mut req = valid_request();
        req.manifest_hash = format!("{:064x}", i);
        create_export_audit(&pool, "u1", &req).await.unwrap();
    }
    let list = list_export_audits_by_project(&pool, "proj-1", Some(2)).await.unwrap();
    assert_eq!(list.len(), 2);
}

#[tokio::test]
async fn count_matches_inserts() {
    let pool = setup_db().await;
    assert_eq!(count_export_audits_by_project(&pool, "proj-1").await.unwrap(), 0);
    create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    assert_eq!(count_export_audits_by_project(&pool, "proj-1").await.unwrap(), 1);
}

#[tokio::test]
async fn global_filter_by_export_type() {
    let pool = setup_db().await;
    create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    let mut req = valid_request();
    req.export_type = "core".to_string();
    req.manifest_hash = "c".repeat(64);
    create_export_audit(&pool, "u1", &req).await.unwrap();

    let fulls = list_export_audits(&pool, None, None, Some("full"), 50).await.unwrap();
    assert_eq!(fulls.len(), 1);
    assert_eq!(fulls[0].export_type, "full");

    let cores = list_export_audits(&pool, None, None, Some("core"), 50).await.unwrap();
    assert_eq!(cores.len(), 1);
    assert_eq!(cores[0].export_type, "core");
}

#[tokio::test]
async fn get_missing_returns_none() {
    let pool = setup_db().await;
    assert!(get_export_audit_by_id(&pool, "nonexistent").await.unwrap().is_none());
}

// ---------------- HTTP handler tests ----------------

#[tokio::test]
async fn post_record_export_success_returns_record_with_user() {
    let pool = setup_db().await;
    let app = app(pool);

    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .header("x-user-id", "alice")
        .body(Body::from(serde_json::to_string(&valid_request()).unwrap()))
        .unwrap();

    let resp = app.oneshot(req).await.unwrap();
    assert_eq!(resp.status(), StatusCode::OK);
    let v = read_json(resp).await;
    assert_eq!(v["user_id"], "alice");
    assert_eq!(v["project_id"], "proj-1");
    assert_eq!(v["export_type"], "full");
    assert_eq!(v["asset_count"], 5);
    assert_eq!(v["missing_asset_count"], 1);
}

#[tokio::test]
async fn post_rejects_short_hash() {
    let pool = setup_db().await;
    let app = app(pool);
    let mut bad = valid_request();
    bad.manifest_hash = "tooshort".to_string();
    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .body(Body::from(serde_json::to_string(&bad).unwrap()))
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn post_rejects_invalid_export_type() {
    let pool = setup_db().await;
    let app = app(pool);
    let mut bad = valid_request();
    bad.export_type = "bogus".to_string();
    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .body(Body::from(serde_json::to_string(&bad).unwrap()))
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn post_404s_unknown_project() {
    let pool = setup_db().await;
    let app = app(pool);
    let mut bad = valid_request();
    bad.project_id = "does-not-exist".to_string();
    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .body(Body::from(serde_json::to_string(&bad).unwrap()))
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn post_rejects_negative_counts() {
    let pool = setup_db().await;
    let app = app(pool);
    let mut bad = valid_request();
    bad.asset_count = -5;
    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .body(Body::from(serde_json::to_string(&bad).unwrap()))
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn list_project_exports_returns_records() {
    let pool = setup_db().await;
    create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    let app = app(pool);
    let req = Request::builder()
        .uri("/api/projects/proj-1/exports?limit=10")
        .body(Body::empty())
        .unwrap();
    let resp = app.oneshot(req).await.unwrap();
    assert_eq!(resp.status(), StatusCode::OK);
    let v = read_json(resp).await;
    assert!(v.is_array());
    assert_eq!(v.as_array().unwrap().len(), 1);
}

#[tokio::test]
async fn list_project_exports_404s_unknown_project() {
    let pool = setup_db().await;
    let app = app(pool);
    let req = Request::builder()
        .uri("/api/projects/nope/exports")
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn list_project_exports_validates_limit() {
    let pool = setup_db().await;
    let app = app(pool);
    let req = Request::builder()
        .uri("/api/projects/proj-1/exports?limit=9999")
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn count_endpoint_returns_count() {
    let pool = setup_db().await;
    create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    let app = app(pool);
    let req = Request::builder()
        .uri("/api/projects/proj-1/exports/count")
        .body(Body::empty())
        .unwrap();
    let resp = app.oneshot(req).await.unwrap();
    assert_eq!(resp.status(), StatusCode::OK);
    let v = read_json(resp).await;
    assert_eq!(v["count"], 1);
}

#[tokio::test]
async fn get_single_audit_returns_200_for_existing() {
    let pool = setup_db().await;
    let rec = create_export_audit(&pool, "u1", &valid_request()).await.unwrap();
    let app = app(pool);
    let req = Request::builder()
        .uri(format!("/api/exports/audit/{}", rec.id))
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::OK);
}

#[tokio::test]
async fn get_single_audit_404_for_missing() {
    let pool = setup_db().await;
    let app = app(pool);
    let req = Request::builder()
        .uri("/api/exports/audit/nope")
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn global_list_filters_work() {
    let pool = setup_db().await;
    create_export_audit(&pool, "alice", &valid_request()).await.unwrap();
    let mut req = valid_request();
    req.export_type = "core".to_string();
    req.manifest_hash = "d".repeat(64);
    create_export_audit(&pool, "bob", &req).await.unwrap();

    let app = app(pool);

    // No filters -> 2 records
    let req = Request::builder().uri("/api/exports/audit").body(Body::empty()).unwrap();
    let v = read_json(app.oneshot(req).await.unwrap()).await;
    assert_eq!(v.as_array().unwrap().len(), 2);

    // Filter by user
    let req = Request::builder()
        .uri("/api/exports/audit?user_id=alice")
        .body(Body::empty())
        .unwrap();
    let v = read_json(app.oneshot(req).await.unwrap()).await;
    assert_eq!(v.as_array().unwrap().len(), 1);
    assert_eq!(v[0]["user_id"], "alice");

    // Invalid export_type returns 400
    let req = Request::builder()
        .uri("/api/exports/audit?export_type=bogus")
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn post_without_user_header_defaults_to_anonymous() {
    let pool = setup_db().await;
    let app = app(pool);
    let req = Request::builder()
        .method("POST")
        .uri("/api/exports/audit")
        .header("content-type", "application/json")
        .body(Body::from(serde_json::to_string(&valid_request()).unwrap()))
        .unwrap();
    let resp = app.oneshot(req).await.unwrap();
    assert_eq!(resp.status(), StatusCode::OK);
    let v = read_json(resp).await;
    assert_eq!(v["user_id"], "anonymous");
}

#[test]
fn valid_request_passes_validation() {
    assert!(valid_request().validate().is_ok());
}

#[test]
fn validate_rejects_non_hex_hash() {
    let mut bad = valid_request();
    bad.manifest_hash = "g".repeat(64);
    let err = bad.validate().unwrap_err();
    assert!(err.iter().any(|e| e.contains("hexadecimal")));
}
