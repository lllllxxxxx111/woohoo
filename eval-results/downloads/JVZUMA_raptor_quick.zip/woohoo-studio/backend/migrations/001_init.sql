-- Initial schema for Woohoo Studio
-- Projects
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    owner_id TEXT NOT NULL,
    settings TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Scripts
CREATE TABLE IF NOT EXISTS scripts (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    scenes TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Storyboards
CREATE TABLE IF NOT EXISTS storyboards (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    shots TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Keyframes
CREATE TABLE IF NOT EXISTS keyframes (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    asset_id TEXT,
    timestamp REAL NOT NULL DEFAULT 0,
    annotations TEXT,
    prompt TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Video plans
CREATE TABLE IF NOT EXISTS video_plans (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    model TEXT NOT NULL DEFAULT '',
    resolution TEXT NOT NULL DEFAULT '{}',
    fps INTEGER NOT NULL DEFAULT 24,
    duration REAL NOT NULL DEFAULT 0,
    parameters TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Assets
CREATE TABLE IF NOT EXISTS assets (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    url TEXT NOT NULL,
    size_bytes INTEGER,
    mime_type TEXT,
    sha256 TEXT,
    metadata TEXT,
    file_path TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Sessions
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    started_at TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at TEXT,
    change_summary TEXT
);

-- Export audit logs (NEW)
-- Design decision: We create a dedicated export_audit_logs table rather than
-- reusing a generic ops/action audit table for these reasons:
-- 1. Export-specific fields (manifest_hash, asset_count, missing_asset_count)
--    are strongly typed and don't fit a generic polymorphic audit schema.
-- 2. Exports have different retention/compliance requirements than general ops logs.
-- 3. Query patterns differ: we need to list exports by project sorted by time,
--    which is simpler with a dedicated table and index.
-- 4. Performance: high-volume ops logs shouldn't slow down export history queries.
-- If a generic audit table is added later, export events can be mirrored there.
CREATE TABLE IF NOT EXISTS export_audit_logs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    export_type TEXT NOT NULL CHECK(export_type IN ('full', 'core', 'snapshot')),
    manifest_hash TEXT NOT NULL,
    asset_count INTEGER NOT NULL DEFAULT 0,
    missing_asset_count INTEGER NOT NULL DEFAULT 0,
    total_size_bytes INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_export_audit_project_id ON export_audit_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_export_audit_created_at ON export_audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_export_audit_user_id ON export_audit_logs(user_id);
