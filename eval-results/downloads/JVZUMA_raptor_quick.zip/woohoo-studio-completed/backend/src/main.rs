use axum::{
    extract::State,
    http::StatusCode,
    response::Json,
    routing::{delete, get, post, put},
    Router,
};
use serde::{Deserialize, Serialize};
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::{Pool, Sqlite};
use std::net::SocketAddr;
use std::str::FromStr;
use std::sync::Arc;
use tower_http::cors::{Any, CorsLayer};
use tower_http::trace::TraceLayer;

mod handlers;
mod models;

use models::preflight::{PreflightIssue, PreflightResult, PreflightSeverity};

#[derive(Clone)]
pub struct AppState {
    pub db: Pool<Sqlite>,
}

pub type AppStateRef = Arc<AppState>;

// ---- Health ----
async fn health() -> &'static str {
    "ok"
}

// ---- Preflight request/response ----
#[derive(Deserialize)]
struct PreflightRequest {
    #[serde(default)]
    project_id: Option<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct PreflightResponse {
    issues: Vec<PreflightIssue>,
    blocking_count: u32,
    warning_count: u32,
    info_count: u32,
    can_export: bool,
    summary: String,
}

/// GET /api/projects/:project_id/preflight
async fn project_preflight(
    State(state): State<AppStateRef>,
    axum::extract::Path(project_id): axum::extract::Path<String>,
) -> Result<Json<PreflightResponse>, StatusCode> {
    let result = handlers::exports::run_preflight(&state.db, &project_id)
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    Ok(Json(PreflightResponse {
        blocking_count: result.blocking_count,
        warning_count: result.warning_count,
        info_count: result.info_count,
        can_export: result.can_export,
        summary: result.summary,
        issues: result.issues,
    }))
}

// ---- Export audit ----
#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct RecordExportRequest {
    project_id: String,
    export_type: String,
    manifest_hash: String,
    #[serde(default)]
    asset_count: i64,
    #[serde(default)]
    missing_asset_count: i64,
    #[serde(default)]
    total_size_bytes: i64,
    #[serde(default)]
    user_id: Option<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ExportAuditRecord {
    id: String,
    user_id: String,
    project_id: String,
    export_type: String,
    manifest_hash: String,
    asset_count: i64,
    missing_asset_count: i64,
    total_size_bytes: i64,
    schema_version: String,
    created_at: String,
}

async fn record_export(
    State(state): State<AppStateRef>,
    Json(body): Json<RecordExportRequest>,
) -> Result<Json<ExportAuditRecord>, (StatusCode, String)> {
    // Validate inputs
    if body.project_id.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "project_id required".into()));
    }
    if body.manifest_hash.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "manifest_hash required".into()));
    }
    let etype = body.export_type.trim().to_lowercase();
    if !["full", "core", "snapshot"].contains(&etype.as_str()) {
        return Err((
            StatusCode::BAD_REQUEST,
            format!("invalid export_type '{}': must be full|core|snapshot", body.export_type),
        ));
    }

    let record = handlers::exports::record_export_audit(
        &state.db,
        body.user_id.as_deref().unwrap_or("anonymous"),
        &body.project_id,
        &etype,
        &body.manifest_hash,
        body.asset_count,
        body.missing_asset_count,
        body.total_size_bytes,
    )
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(Json(record))
}

async fn list_project_exports(
    State(state): State<AppStateRef>,
    axum::extract::Path(project_id): axum::extract::Path<String>,
) -> Result<Json<Vec<ExportAuditRecord>>, (StatusCode, String)> {
    let records = handlers::exports::list_export_audits(&state.db, &project_id)
        .await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(records))
}

async fn list_all_exports(
    State(state): State<AppStateRef>,
) -> Result<Json<Vec<ExportAuditRecord>>, (StatusCode, String)> {
    let records = handlers::exports::list_all_export_audits(&state.db)
        .await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(records))
}

fn app_router(state: AppStateRef) -> Router {
    Router::new()
        .route("/health", get(health))
        // Projects CRUD
        .route("/api/projects", get(handlers::projects::list_projects).post(handlers::projects::create_project))
        .route(
            "/api/projects/:id",
            get(handlers::projects::get_project)
                .put(handlers::projects::update_project)
                .delete(handlers::projects::delete_project),
        )
        // Scripts
        .route(
            "/api/projects/:id/scripts",
            get(handlers::scripts::list_scripts).post(handlers::scripts::create_script),
        )
        // Storyboards
        .route(
            "/api/projects/:id/storyboards",
            get(handlers::storyboards::list_storyboards),
        )
        // Keyframes
        .route(
            "/api/projects/:id/keyframes",
            get(handlers::keyframes::list_keyframes),
        )
        // Video plans
        .route(
            "/api/projects/:id/video-plans",
            get(handlers::videoplans::list_video_plans),
        )
        // Assets
        .route(
            "/api/projects/:id/assets",
            get(handlers::assets::list_assets).post(handlers::assets::upload_asset),
        )
        .route("/api/assets/:id/download", get(handlers::assets::download_asset))
        // Sessions
        .route("/api/projects/:id/sessions", get(handlers::sessions::list_sessions))
        // Preflight
        .route("/api/projects/:id/preflight", get(project_preflight))
        // Export audit
        .route("/api/exports/audit", get(list_all_exports).post(record_export))
        .route("/api/projects/:id/exports", get(list_project_exports))
        .layer(
            CorsLayer::new()
                .allow_origin(Any)
                .allow_methods(Any)
                .allow_headers(Any),
        )
        .layer(TraceLayer::new_for_http())
        .with_state(state)
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "woohoo_studio=info,tower_http=info".into()),
        )
        .init();

    let db_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "sqlite://woohoo-studio.db?mode=rwc".to_string());
    let options = SqliteConnectOptions::from_str(&db_url)?
        .create_if_missing(true)
        .foreign_keys(true);
    let pool = SqlitePoolOptions::new()
        .max_connections(5)
        .connect_with(options)
        .await?;

    // Run migrations
    sqlx::raw_sql(include_str!("../migrations/001_init.sql"))
        .execute(&pool)
        .await?;
    tracing::info!("migrations applied");

    let state = Arc::new(AppState { db: pool });

    let addr: SocketAddr = std::env::var("BIND_ADDR")
        .unwrap_or_else(|_| "0.0.0.0:4000".into())
        .parse()?;
    tracing::info!(%addr, "starting Woohoo Studio backend");

    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app_router(state)).await?;
    Ok(())
}

// Expose router for tests
pub fn test_app(state: AppStateRef) -> Router {
    app_router(state)
}
