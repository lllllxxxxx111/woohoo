
use crate::models::exports::ExportAuditRecord;
use crate::models::preflight::{PreflightIssue, PreflightResult, PreflightSeverity};
use sqlx::SqlitePool;

/// Run server-side preflight checks by inspecting DB state for the project.
pub async fn run_preflight(db: &SqlitePool, project_id: &str) -> Result<PreflightResult, sqlx::Error> {
    let mut issues: Vec<PreflightIssue> = Vec::new();

    // Check project exists
    let project = sqlx::query!(r#"SELECT id, name, description FROM projects WHERE id = ?"#, project_id)
        .fetch_optional(db)
        .await?;
    if project.is_none() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "project_not_found".into(),
            message: format!("Project {project_id} does not exist"),
            entity_type: Some("project".into()),
            entity_id: Some(project_id.to_string()),
            detail: None,
        });
        return Ok(summarize(issues));
    }
    let project = project.unwrap();

    if project.description.as_deref().map_or(true, |s| s.trim().is_empty()) {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "project_no_description".into(),
            message: "Project has no description".into(),
            entity_type: Some("project".into()),
            entity_id: Some(project_id.to_string()),
            detail: None,
        });
    }

    // Scripts
    let scripts = sqlx::query!(
        r#"SELECT id, title, content FROM scripts WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if scripts.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "no_scripts".into(),
            message: "Project has no scripts; at least one script is required for export".into(),
            entity_type: Some("script".into()), entity_id: None, detail: None,
        });
    } else {
        for s in &scripts {
            if s.content.trim().is_empty() {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "empty_script_content".into(),
                    message: format!("Script '{}' has empty content", s.title),
                    entity_type: Some("script".into()),
                    entity_id: Some(s.id.clone()),
                    detail: None,
                });
            }
        }
    }

    // Storyboards
    let storyboards = sqlx::query!(
        r#"SELECT id, name, shots FROM storyboards WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if storyboards.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "no_storyboards".into(),
            message: "Project has no storyboards; at least one storyboard is required for export".into(),
            entity_type: Some("storyboard".into()), entity_id: None, detail: None,
        });
    } else {
        for sb in &storyboards {
            let shots: Vec<serde_json::Value> = serde_json::from_str(&sb.shots).unwrap_or_default();
            for shot in shots {
                let kf = shot.get("keyframeIds").and_then(|v| v.as_array());
                if kf.map_or(true, |arr| arr.is_empty()) {
                    issues.push(PreflightIssue {
                        severity: PreflightSeverity::Warning,
                        code: "shot_no_keyframes".into(),
                        message: format!("Shot in storyboard '{}' has no keyframes", sb.name),
                        entity_type: Some("shot".into()),
                        entity_id: shot.get("id").and_then(|v| v.as_str()).map(String::from),
                        detail: None,
                    });
                }
            }
        }
    }

    // Keyframes
    let keyframes = sqlx::query!(
        r#"SELECT id, name, asset_id FROM keyframes WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    let asset_ids: Vec<String> = {
        let mut ids = Vec::new();
        for kf in &keyframes {
            if let Some(aid) = &kf.asset_id {
                ids.push(aid.clone());
            }
        }
        ids
    };

    // Assets
    let assets = sqlx::query!(
        r#"SELECT id, name, type as kind, url, size_bytes, sha256 FROM assets WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if assets.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "no_assets".into(),
            message: "Project has no binary assets".into(),
            entity_type: None, entity_id: None, detail: None,
        });
    }

    let known_asset_ids: std::collections::HashSet<&str> =
        assets.iter().map(|a| a.id.as_str()).collect();
    let mut name_counts: std::collections::HashMap<&str, u32> = std::collections::HashMap::new();
    for a in &assets {
        *name_counts.entry(a.name.as_str()).or_insert(0) += 1;
    }

    for a in &assets {
        if a.url.trim().is_empty() || !is_valid_url(&a.url) {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Blocking,
                code: "asset_invalid_url".into(),
                message: format!("Asset '{}' has missing or invalid URL", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: Some(a.url.clone()),
            });
        }
        if a.sha256.as_deref().map_or(true, |s| s.is_empty()) {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Info,
                code: "asset_no_sha256".into(),
                message: format!("Asset '{}' has no recorded SHA-256 checksum", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: None,
            });
        }
        if name_counts.get(a.name.as_str()).copied().unwrap_or(0) > 1 {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Warning,
                code: "duplicate_asset_name".into(),
                message: format!("Duplicate asset filename: '{}'", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: None,
            });
        }
    }

    // Keyframes pointing to unknown assets
    for kf in &keyframes {
        if let Some(aid) = &kf.asset_id {
            if !known_asset_ids.contains(aid.as_str()) {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "keyframe_missing_asset".into(),
                    message: format!("Keyframe '{}' references missing asset '{}'", kf.name, aid),
                    entity_type: Some("keyframe".into()),
                    entity_id: Some(kf.id.clone()),
                    detail: None,
                });
            }
        }
    }

    // Video plans
    let video_plans = sqlx::query!(
        r#"SELECT id, name, model FROM video_plans WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if video_plans.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "no_video_plans".into(),
            message: "Project has no video generation plans configured".into(),
            entity_type: None, entity_id: None, detail: None,
        });
    } else {
        for vp in &video_plans {
            if vp.model.trim().is_empty() {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "video_plan_no_model".into(),
                    message: format!("Video plan '{}' has no model specified", vp.name),
                    entity_type: Some("video_plan".into()),
                    entity_id: Some(vp.id.clone()),
                    detail: None,
                });
            }
        }
    }

    Ok(summarize(issues))
}

fn is_valid_url(u: &str) -> bool {
    // Accept http(s), local://, blob:, data:, relative paths
    let lower = u.trim().to_lowercase();
    lower.starts_with("http://") || lower.starts_with("https://")
        || lower.starts_with("local://") || lower.starts_with("blob:")
        || lower.starts_with("data:") || lower.starts_with('/')
}

fn summarize(issues: Vec<PreflightIssue>) -> PreflightResult {
    let mut blocking = 0u32;
    let mut warning = 0u32;
    let mut info = 0u32;
    for i in &issues {
        match i.severity {
            PreflightSeverity::Blocking => blocking += 1,
            PreflightSeverity::Warning => warning += 1,
            PreflightSeverity::Info => info += 1,
        }
    }
    let can_export = blocking == 0;
    let summary = if can_export {
        if warning > 0 {
            format!("{blocking} blocking, {warning} warning(s), {info} info. Export allowed but review warnings.")
        } else {
            format!("All checks passed ({info} info). Ready to export.")
        }
    } else {
        format!("{blocking} blocking issue(s) must be resolved before export. {warning} warning(s), {info} info.")
    };
    PreflightResult {
        issues, blocking_count: blocking, warning_count: warning, info_count: info,
        can_export, summary,
    }
}

pub async fn record_export_audit(
    db: &SqlitePool,
    user_id: &str,
    project_id: &str,
    export_type: &str,
    manifest_hash: &str,
    asset_count: i64,
    missing_asset_count: i64,
    total_size_bytes: i64,
) -> Result<ExportAuditRecord, sqlx::Error> {
    let record = ExportAuditRecord::new(
        user_id.to_string(),
        project_id.to_string(),
        export_type.to_string(),
        manifest_hash.to_string(),
        asset_count,
        missing_asset_count,
        total_size_bytes,
    );
    sqlx::query!(
        r#"INSERT INTO export_audit_logs (id, user_id, project_id, export_type, manifest_hash,
            asset_count, missing_asset_count, total_size_bytes, schema_version, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"#,
        record.id, record.user_id, record.project_id, record.export_type,
        record.manifest_hash, record.asset_count, record.missing_asset_count,
        record.total_size_bytes, record.schema_version, record.created_at
    )
    .execute(db)
    .await?;
    Ok(record)
}

pub async fn list_export_audits(
    db: &SqlitePool,
    project_id: &str,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    struct Row {
        id: String, user_id: String, project_id: String, export_type: String,
        manifest_hash: String, asset_count: i64, missing_asset_count: i64,
        total_size_bytes: i64, schema_version: String, created_at: String,
    }
    let rows = sqlx::query_as!(
        Row,
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, schema_version, created_at
           FROM export_audit_logs WHERE project_id = ? ORDER BY created_at DESC LIMIT 100"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    Ok(rows.into_iter().map(|r| ExportAuditRecord {
        id: r.id, user_id: r.user_id, project_id: r.project_id, export_type: r.export_type,
        manifest_hash: r.manifest_hash, asset_count: r.asset_count,
        missing_asset_count: r.missing_asset_count, total_size_bytes: r.total_size_bytes,
        schema_version: r.schema_version, created_at: r.created_at,
    }).collect())
}

pub async fn list_all_export_audits(
    db: &SqlitePool,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    struct Row {
        id: String, user_id: String, project_id: String, export_type: String,
        manifest_hash: String, asset_count: i64, missing_asset_count: i64,
        total_size_bytes: i64, schema_version: String, created_at: String,
    }
    let rows = sqlx::query_as!(
        Row,
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, schema_version, created_at
           FROM export_audit_logs ORDER BY created_at DESC LIMIT 500"#
    )
    .fetch_all(db)
    .await?;
    Ok(rows.into_iter().map(|r| ExportAuditRecord {
        id: r.id, user_id: r.user_id, project_id: r.project_id, export_type: r.export_type,
        manifest_hash: r.manifest_hash, asset_count: r.asset_count,
        missing_asset_count: r.missing_asset_count, total_size_bytes: r.total_size_bytes,
        schema_version: r.schema_version, created_at: r.created_at,
    }).collect())
}
