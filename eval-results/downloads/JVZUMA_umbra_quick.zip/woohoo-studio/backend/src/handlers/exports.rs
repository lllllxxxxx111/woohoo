
use crate::models::exports::ExportAuditRecord;
use crate::models::preflight::{PreflightIssue, PreflightResult, PreflightSeverity};
use sqlx::SqlitePool;

/// Run server-side preflight checks by inspecting DB state for the project.
/// Mirrors the frontend rules in `src/utils/preflight.ts`; keep in sync.
pub async fn run_preflight(db: &SqlitePool, project_id: &str) -> Result<PreflightResult, sqlx::Error> {
    let mut issues: Vec<PreflightIssue> = Vec::new();

    let project = sqlx::query!(r#"SELECT id, name, description FROM projects WHERE id = ?"#, project_id)
        .fetch_optional(db)
        .await?;
    if project.is_none() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "project_not_found".into(),
            message: format!("Project {project_id} does not exist"),
            entity_type: Some("project".into()),
            entity_id: Some(project_id.to_string()),
            detail: None,
        });
        return Ok(summarize(issues));
    }
    let project = project.unwrap();

    if project.description.as_deref().map_or(true, |s| s.trim().is_empty()) {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "project_no_description".into(),
            message: "Project has no description".into(),
            entity_type: Some("project".into()),
            entity_id: Some(project_id.to_string()),
            detail: None,
        });
    }

    // Scripts
    let scripts = sqlx::query!(
        r#"SELECT id, title, content FROM scripts WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if scripts.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "no_scripts".into(),
            message: "Project has no scripts; at least one script is required for export".into(),
            entity_type: Some("script".into()), entity_id: None, detail: None,
        });
    } else {
        for s in &scripts {
            if s.content.trim().is_empty() {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "script_empty".into(),
                    message: format!("Script '{}' has empty content", s.title),
                    entity_type: Some("script".into()),
                    entity_id: Some(s.id.clone()),
                    detail: None,
                });
            }
        }
    }

    // Storyboards
    let storyboards = sqlx::query!(
        r#"SELECT id, name, shots FROM storyboards WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if storyboards.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Blocking,
            code: "no_storyboards".into(),
            message: "Project has no storyboards; at least one storyboard is required for export".into(),
            entity_type: Some("storyboard".into()), entity_id: None, detail: None,
        });
    } else {
        for sb in &storyboards {
            let shots: Vec<serde_json::Value> = serde_json::from_str(&sb.shots).unwrap_or_default();
            if shots.is_empty() {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "storyboard_empty".into(),
                    message: format!("Storyboard '{}' has no shots", sb.name),
                    entity_type: Some("storyboard".into()),
                    entity_id: Some(sb.id.clone()),
                    detail: None,
                });
            }
            for shot in shots {
                let shot_id = shot.get("id").and_then(|v| v.as_str()).map(String::from);
                let number = shot.get("number").and_then(|v| v.as_i64()).unwrap_or(-1);
                let desc = shot.get("description").and_then(|v| v.as_str()).unwrap_or("");
                let kf = shot.get("keyframeIds").and_then(|v| v.as_array());

                if desc.trim().is_empty() {
                    issues.push(PreflightIssue {
                        severity: PreflightSeverity::Warning,
                        code: "shot_empty_description".into(),
                        message: format!("Shot #{} in storyboard '{}' has no description", number, sb.name),
                        entity_type: Some("shot".into()),
                        entity_id: shot_id.clone(),
                        detail: None,
                    });
                }
                if kf.map_or(true, |arr| arr.is_empty()) {
                    issues.push(PreflightIssue {
                        severity: PreflightSeverity::Warning,
                        code: "shot_no_keyframes".into(),
                        message: format!("Shot #{} in storyboard '{}' has no keyframes", number, sb.name),
                        entity_type: Some("shot".into()),
                        entity_id: shot_id,
                        detail: None,
                    });
                }
            }
        }
    }

    // Keyframes
    let keyframes = sqlx::query!(
        r#"SELECT id, name, asset_id, prompt, annotations FROM keyframes WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;

    // Assets
    let assets = sqlx::query!(
        r#"SELECT id, name, url, size_bytes, sha256 FROM assets WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if assets.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "no_assets".into(),
            message: "Project has no binary assets".into(),
            entity_type: None, entity_id: None, detail: None,
        });
    }

    let known_asset_ids: std::collections::HashSet<&str> =
        assets.iter().map(|a| a.id.as_str()).collect();
    let mut name_counts: std::collections::HashMap<&str, u32> = std::collections::HashMap::new();
    for a in &assets {
        *name_counts.entry(a.name.as_str()).or_insert(0) += 1;
    }

    for a in &assets {
        if a.url.trim().is_empty() || !is_valid_url(&a.url) {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Blocking,
                code: "asset_invalid_url".into(),
                message: format!("Asset '{}' has missing or invalid URL", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: Some(a.url.clone()),
            });
        }
        if a.size_bytes.map_or(false, |n| n <= 0) {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Blocking,
                code: "asset_empty".into(),
                message: format!("Asset '{}' has size {} bytes; cannot pack an empty file", a.name, a.size_bytes.unwrap_or(0)),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: a.size_bytes.map(|n| n.to_string()),
            });
        }
        if a.sha256.as_deref().map_or(true, |s| s.is_empty()) {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Info,
                code: "asset_no_sha256".into(),
                message: format!("Asset '{}' has no recorded SHA-256 checksum", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: None,
            });
        }
        if name_counts.get(a.name.as_str()).copied().unwrap_or(0) > 1 {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Warning,
                code: "duplicate_asset_name".into(),
                message: format!("Duplicate asset filename: '{}'", a.name),
                entity_type: Some("asset".into()),
                entity_id: Some(a.id.clone()),
                detail: None,
            });
        }
    }

    for kf in &keyframes {
        match &kf.asset_id {
            None => {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "keyframe_no_asset".into(),
                    message: format!("Keyframe '{}' has no associated asset", kf.name),
                    entity_type: Some("keyframe".into()),
                    entity_id: Some(kf.id.clone()),
                    detail: None,
                });
            }
            Some(aid) if !known_asset_ids.contains(aid.as_str()) => {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "keyframe_missing_asset".into(),
                    message: format!("Keyframe '{}' references missing asset '{}'", kf.name, aid),
                    entity_type: Some("keyframe".into()),
                    entity_id: Some(kf.id.clone()),
                    detail: None,
                });
            }
            _ => {}
        }
        let has_prompt = kf.prompt.as_deref().map_or(false, |s| !s.trim().is_empty());
        let has_notes = kf.annotations.as_deref().map_or(false, |s| !s.trim().is_empty());
        if !has_prompt && !has_notes {
            issues.push(PreflightIssue {
                severity: PreflightSeverity::Info,
                code: "keyframe_no_notes".into(),
                message: format!("Keyframe '{}' has no prompt or annotations", kf.name),
                entity_type: Some("keyframe".into()),
                entity_id: Some(kf.id.clone()),
                detail: None,
            });
        }
    }

    let video_plans = sqlx::query!(
        r#"SELECT id, name, model, fps, duration, resolution FROM video_plans WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(db)
    .await?;
    if video_plans.is_empty() {
        issues.push(PreflightIssue {
            severity: PreflightSeverity::Info,
            code: "no_video_plans".into(),
            message: "Project has no video generation plans configured".into(),
            entity_type: None, entity_id: None, detail: None,
        });
    } else {
        for vp in &video_plans {
            if vp.model.trim().is_empty() {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "video_plan_no_model".into(),
                    message: format!("Video plan '{}' has no model specified", vp.name),
                    entity_type: Some("video_plan".into()),
                    entity_id: Some(vp.id.clone()),
                    detail: None,
                });
            }
            if vp.duration <= 0.0 {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Warning,
                    code: "video_plan_zero_duration".into(),
                    message: format!("Video plan '{}' has zero or invalid duration", vp.name),
                    entity_type: Some("video_plan".into()),
                    entity_id: Some(vp.id.clone()),
                    detail: None,
                });
            }
            let res: Option<serde_json::Value> = serde_json::from_str(vp.resolution.as_str()).ok();
            let w = res.as_ref().and_then(|r| r.get("width")).and_then(|v| v.as_i64()).unwrap_or(0);
            let h = res.as_ref().and_then(|r| r.get("height")).and_then(|v| v.as_i64()).unwrap_or(0);
            if w <= 0 || h <= 0 {
                issues.push(PreflightIssue {
                    severity: PreflightSeverity::Info,
                    code: "video_plan_bad_resolution".into(),
                    message: format!("Video plan '{}' has no valid resolution set", vp.name),
                    entity_type: Some("video_plan".into()),
                    entity_id: Some(vp.id.clone()),
                    detail: None,
                });
            }
        }
    }

    Ok(summarize(issues))
}

fn is_valid_url(u: &str) -> bool {
    let lower = u.trim().to_lowercase();
    lower.starts_with("http://") || lower.starts_with("https://")
        || lower.starts_with("local://") || lower.starts_with("blob:")
        || lower.starts_with("data:") || lower.starts_with("//")
        || lower.starts_with('/')
}

fn summarize(issues: Vec<PreflightIssue>) -> PreflightResult {
    let mut blocking = 0u32;
    let mut warning = 0u32;
    let mut info = 0u32;
    for i in &issues {
        match i.severity {
            PreflightSeverity::Blocking => blocking += 1,
            PreflightSeverity::Warning => warning += 1,
            PreflightSeverity::Info => info += 1,
        }
    }
    let can_export = blocking == 0;
    let summary = if can_export {
        if warning > 0 {
            format!("{blocking} blocking, {warning} warning(s), {info} info. Export allowed but review warnings.")
        } else {
            format!("All checks passed ({info} info). Ready to export.")
        }
    } else {
        format!("{blocking} blocking issue(s) must be resolved before export. {warning} warning(s), {info} info.")
    };
    PreflightResult {
        issues, blocking_count: blocking, warning_count: warning, info_count: info,
        can_export, summary,
    }
}

pub async fn record_export_audit(
    db: &SqlitePool,
    user_id: &str,
    project_id: &str,
    export_type: &str,
    manifest_hash: &str,
    asset_count: i64,
    missing_asset_count: i64,
    total_size_bytes: i64,
) -> Result<ExportAuditRecord, sqlx::Error> {
    let record = ExportAuditRecord::new(
        user_id.to_string(),
        project_id.to_string(),
        export_type.to_string(),
        manifest_hash.to_string(),
        asset_count.max(0),
        missing_asset_count.max(0),
        total_size_bytes.max(0),
    );
    sqlx::query!(
        r#"INSERT INTO export_audit_logs (id, user_id, project_id, export_type, manifest_hash,
            asset_count, missing_asset_count, total_size_bytes, schema_version, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"#,
        record.id, record.user_id, record.project_id, record.export_type,
        record.manifest_hash, record.asset_count, record.missing_asset_count,
        record.total_size_bytes, record.schema_version, record.created_at
    )
    .execute(db)
    .await?;
    Ok(record)
}

pub async fn list_export_audits(
    db: &SqlitePool,
    project_id: &str,
    limit: i64,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    let limit = limit.clamp(1, 1000);
    struct Row {
        id: String, user_id: String, project_id: String, export_type: String,
        manifest_hash: String, asset_count: i64, missing_asset_count: i64,
        total_size_bytes: i64, schema_version: String, created_at: String,
    }
    let rows = sqlx::query_as!(
        Row,
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, schema_version, created_at
           FROM export_audit_logs WHERE project_id = ? ORDER BY created_at DESC LIMIT ?"#,
        project_id,
        limit
    )
    .fetch_all(db)
    .await?;
    Ok(rows.into_iter().map(|r| ExportAuditRecord {
        id: r.id, user_id: r.user_id, project_id: r.project_id, export_type: r.export_type,
        manifest_hash: r.manifest_hash, asset_count: r.asset_count,
        missing_asset_count: r.missing_asset_count, total_size_bytes: r.total_size_bytes,
        schema_version: r.schema_version, created_at: r.created_at,
    }).collect())
}

pub async fn list_all_export_audits(
    db: &SqlitePool,
    limit: i64,
) -> Result<Vec<ExportAuditRecord>, sqlx::Error> {
    let limit = limit.clamp(1, 5000);
    struct Row {
        id: String, user_id: String, project_id: String, export_type: String,
        manifest_hash: String, asset_count: i64, missing_asset_count: i64,
        total_size_bytes: i64, schema_version: String, created_at: String,
    }
    let rows = sqlx::query_as!(
        Row,
        r#"SELECT id, user_id, project_id, export_type, manifest_hash, asset_count,
                  missing_asset_count, total_size_bytes, schema_version, created_at
           FROM export_audit_logs ORDER BY created_at DESC LIMIT ?"#,
        limit
    )
    .fetch_all(db)
    .await?;
    Ok(rows.into_iter().map(|r| ExportAuditRecord {
        id: r.id, user_id: r.user_id, project_id: r.project_id, export_type: r.export_type,
        manifest_hash: r.manifest_hash, asset_count: r.asset_count,
        missing_asset_count: r.missing_asset_count, total_size_bytes: r.total_size_bytes,
        schema_version: r.schema_version, created_at: r.created_at,
    }).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn is_valid_url_accepts_common_shapes() {
        for u in ["https://cdn.example.com/a.png", "http://x", "//cdn/a.png",
                  "/api/assets/a1/download", "blob:http://localhost/abc",
                  "data:image/png;base64,AAAA", "local://tmp/x.png"] {
            assert!(is_valid_url(u), "expected valid: {u}");
        }
        for u in ["", "not a url", "C:\Windows\file", "garbage:text"] {
            assert!(!is_valid_url(u), "expected invalid: {u}");
        }
    }

    #[test]
    fn summarize_counts_severities() {
        let issues = vec![
            PreflightIssue {
                severity: PreflightSeverity::Blocking, code: "x".into(), message: "".into(),
                entity_type: None, entity_id: None, detail: None,
            },
            PreflightIssue {
                severity: PreflightSeverity::Warning, code: "y".into(), message: "".into(),
                entity_type: None, entity_id: None, detail: None,
            },
            PreflightIssue {
                severity: PreflightSeverity::Info, code: "z".into(), message: "".into(),
                entity_type: None, entity_id: None, detail: None,
            },
        ];
        let r = summarize(issues);
        assert_eq!(r.blocking_count, 1);
        assert_eq!(r.warning_count, 1);
        assert_eq!(r.info_count, 1);
        assert!(!r.can_export);
        assert!(r.summary.contains("blocking"));
    }

    #[test]
    fn summarize_allows_export_when_no_blocking() {
        let r = summarize(vec![
            PreflightIssue {
                severity: PreflightSeverity::Warning, code: "w".into(), message: "".into(),
                entity_type: None, entity_id: None, detail: None,
            },
        ]);
        assert!(r.can_export);
        assert_eq!(r.blocking_count, 0);
    }
}
