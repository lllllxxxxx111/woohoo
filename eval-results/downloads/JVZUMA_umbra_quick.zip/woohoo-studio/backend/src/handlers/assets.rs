
use crate::models::assets::{Asset, CreateAsset};
use crate::AppStateRef;
use axum::extract::{Multipart, Path, State};
use axum::http::StatusCode;
use axum::response::{Json, Response};
use axum::body::Body;
use axum::http::header;

pub async fn list_assets(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<Asset>>, (StatusCode, String)> {
    struct AssetRow {
        id: String, project_id: String, name: String, kind: String, url: String,
        size_bytes: Option<i64>, mime_type: Option<String>, sha256: Option<String>,
        metadata: Option<String>, created_at: String,
    }
    let rows = sqlx::query_as!(
        AssetRow,
        r#"SELECT id, project_id, name, type as kind, url, size_bytes, mime_type, sha256, metadata, created_at
           FROM assets WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    let assets: Vec<Asset> = rows.into_iter().map(|r| Asset {
        id: r.id, project_id: r.project_id, name: r.name, kind: r.kind, url: r.url,
        size_bytes: r.size_bytes, mime_type: r.mime_type, sha256: r.sha256,
        metadata: r.metadata, created_at: r.created_at, file_data: None,
    }).collect();
    Ok(Json(assets))
}

pub async fn upload_asset(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
    mut multipart: Multipart,
) -> Result<Json<Asset>, (StatusCode, String)> {
    let mut name: Option<String> = None;
    let mut kind: Option<String> = None;
    let mut url: Option<String> = None;
    let mut file_data: Option<Vec<u8>> = None;
    let mut mime_type: Option<String> = None;

    while let Some(field) = multipart.next_field().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))? {
        let field_name = field.name().unwrap_or("").to_string();
        if field_name == "name" {
            name = Some(field.text().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?);
        } else if field_name == "type" {
            kind = Some(field.text().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?);
        } else if field_name == "url" {
            url = Some(field.text().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?);
        } else if field_name == "file" {
            mime_type = field.content_type().map(|s| s.to_string());
            let bytes = field.bytes().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?;
            file_data = Some(bytes.to_vec());
        }
    }

    let name = name.ok_or((StatusCode::BAD_REQUEST, "name required".to_string()))?;
    let kind = kind.unwrap_or_else(|| "document".to_string());
    let url = url.unwrap_or_else(|| "local://uploaded".to_string());
    let size_bytes = file_data.as_ref().map(|d| d.len() as i64);

    let asset = Asset::new(project_id, name, kind, url, size_bytes, mime_type.clone(), None, None, file_data);
    sqlx::query!(
        r#"INSERT INTO assets (id, project_id, name, type, url, size_bytes, mime_type, sha256, metadata, file_data, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"#,
        asset.id, asset.project_id, asset.name, asset.kind, asset.url,
        asset.size_bytes, asset.mime_type, asset.sha256, asset.metadata, asset.file_data,
        asset.created_at
    )
    .execute(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(asset))
}

pub async fn download_asset(
    State(state): State<AppStateRef>,
    Path(id): Path<String>,
) -> Result<Response, (StatusCode, String)> {
    struct Row {
        name: String, mime_type: Option<String>, file_data: Option<Vec<u8>>, url: String,
    }
    let row = sqlx::query_as!(
        Row,
        r#"SELECT name, mime_type, file_data, url FROM assets WHERE id = ?"#,
        id
    )
    .fetch_optional(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    .ok_or((StatusCode::NOT_FOUND, format!("asset {id} not found")))?;

    if let Some(data) = row.file_data {
        let ct = row.mime_type.unwrap_or_else(|| "application/octet-stream".to_string());
        let body = Body::from(data);
        Ok(Response::builder()
            .status(StatusCode::OK)
            .header(header::CONTENT_TYPE, ct)
            .header(header::CONTENT_DISPOSITION, format!("attachment; filename=\"{}\"", row.name))
            .body(body)
            .unwrap())
    } else {
        // Redirect to external URL
        Ok(Response::builder()
            .status(StatusCode::SEE_OTHER)
            .header(header::LOCATION, &row.url)
            .body(Body::empty())
            .unwrap())
    }
}
