
use crate::models::projects::{CreateProject, Project, UpdateProject};
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_projects(
    State(state): State<AppStateRef>,
) -> Result<Json<Vec<Project>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        Project,
        r#"SELECT id, name, description, owner_id, settings, created_at, updated_at FROM projects ORDER BY created_at DESC"#
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}

pub async fn get_project(
    State(state): State<AppStateRef>,
    Path(id): Path<String>,
) -> Result<Json<Project>, (StatusCode, String)> {
    let row = sqlx::query_as!(
        Project,
        r#"SELECT id, name, description, owner_id, settings, created_at, updated_at FROM projects WHERE id = ?"#,
        id
    )
    .fetch_optional(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    row.map(Json).ok_or((StatusCode::NOT_FOUND, format!("project {id} not found")))
}

pub async fn create_project(
    State(state): State<AppStateRef>,
    Json(body): Json<CreateProject>,
) -> Result<Json<Project>, (StatusCode, String)> {
    if body.name.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "name required".into()));
    }
    let settings_json = body.settings.map(|s| s.to_string());
    let project = Project::new(body.name, body.description, body.owner_id, body.settings);
    sqlx::query!(
        r#"INSERT INTO projects (id, name, description, owner_id, settings, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)"#,
        project.id, project.name, project.description, project.owner_id,
        settings_json.as_deref().or(project.settings.as_deref()),
        project.created_at, project.updated_at
    )
    .execute(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(project))
}

pub async fn update_project(
    State(state): State<AppStateRef>,
    Path(id): Path<String>,
    Json(body): Json<UpdateProject>,
) -> Result<Json<Project>, (StatusCode, String)> {
    let existing = sqlx::query_as!(
        Project,
        r#"SELECT id, name, description, owner_id, settings, created_at, updated_at FROM projects WHERE id = ?"#,
        id
    )
    .fetch_optional(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    .ok_or((StatusCode::NOT_FOUND, format!("project {id} not found")))?;

    let new_name = body.name.unwrap_or(existing.name);
    let new_desc = body.description.or(existing.description);
    let new_settings = body.settings.map(|s| s.to_string()).or(existing.settings);
    let now = Utc::now().to_rfc3339();

    sqlx::query!(
        r#"UPDATE projects SET name = ?, description = ?, settings = ?, updated_at = ? WHERE id = ?"#,
        new_name, new_desc, new_settings, now, id
    )
    .execute(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(Json(Project {
        id, name: new_name, description: new_desc, owner_id: existing.owner_id,
        settings: new_settings, created_at: existing.created_at, updated_at: now,
    }))
}

pub async fn delete_project(
    State(state): State<AppStateRef>,
    Path(id): Path<String>,
) -> Result<StatusCode, (StatusCode, String)> {
    let res = sqlx::query!(r#"DELETE FROM projects WHERE id = ?"#, id)
        .execute(&state.db)
        .await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    if res.rows_affected() == 0 {
        Err((StatusCode::NOT_FOUND, format!("project {id} not found")))
    } else {
        Ok(StatusCode::NO_CONTENT)
    }
}
