
use crate::models::sessions::Session;
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_sessions(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<Session>>, (StatusCode, String)> {
    // sessions table has user_id but the API path is /projects/:id/sessions
    let rows = sqlx::query_as!(
        Session,
        r#"SELECT id, project_id, user_id, started_at, ended_at, change_summary
           FROM sessions WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}
