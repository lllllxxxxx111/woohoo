
use crate::models::videoplans::VideoPlan;
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_video_plans(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<VideoPlan>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        VideoPlan,
        r#"SELECT id, project_id, name, model, resolution, fps, duration, parameters, created_at, updated_at
           FROM video_plans WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}
