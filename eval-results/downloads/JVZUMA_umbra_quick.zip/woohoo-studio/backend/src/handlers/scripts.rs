
use crate::models::scripts::{CreateScript, Script};
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_scripts(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<Script>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        Script,
        r#"SELECT id, project_id, title, content, scenes, created_at, updated_at FROM scripts WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}

pub async fn create_script(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
    Json(body): Json<CreateScript>,
) -> Result<Json<Script>, (StatusCode, String)> {
    if body.title.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "title required".into()));
    }
    let script = Script::new(project_id, body.title, body.content, body.scenes);
    sqlx::query!(
        r#"INSERT INTO scripts (id, project_id, title, content, scenes, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)"#,
        script.id, script.project_id, script.title, script.content,
        script.scenes, script.created_at, script.updated_at
    )
    .execute(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(script))
}
