
use crate::models::keyframes::Keyframe;
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_keyframes(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<Keyframe>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        Keyframe,
        r#"SELECT id, project_id, name, asset_id, timestamp, annotations, prompt, created_at
           FROM keyframes WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}
