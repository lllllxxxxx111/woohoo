
use crate::models::storyboards::Storyboard;
use crate::AppStateRef;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

pub async fn list_storyboards(
    State(state): State<AppStateRef>,
    Path(project_id): Path<String>,
) -> Result<Json<Vec<Storyboard>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        Storyboard,
        r#"SELECT id, project_id, name, shots, created_at, updated_at FROM storyboards WHERE project_id = ?"#,
        project_id
    )
    .fetch_all(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(rows))
}
