use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct Script {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    pub title: String,
    pub content: String,
    pub scenes: String,
    #[serde(rename = "createdAt")]
    #[sqlx(rename = "created_at")]
    pub created_at: String,
    #[serde(rename = "updatedAt")]
    #[sqlx(rename = "updated_at")]
    pub updated_at: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateScript {
    pub title: String,
    #[serde(default)]
    pub content: String,
    #[serde(default)]
    pub scenes: Vec<serde_json::Value>,
}

impl Script {
    pub fn new(project_id: String, title: String, content: String, scenes: Vec<serde_json::Value>) -> Self {
        let now = Utc::now().to_rfc3339();
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            title,
            content,
            scenes: serde_json::to_string(&scenes).unwrap_or_else(|_| "[]".to_string()),
            created_at: now.clone(),
            updated_at: now,
        }
    }
}
