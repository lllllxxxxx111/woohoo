
use chrono::Utc;
use serde::Serialize;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ExportAuditRecord {
    pub id: String,
    pub user_id: String,
    pub project_id: String,
    pub export_type: String,
    pub manifest_hash: String,
    pub asset_count: i64,
    pub missing_asset_count: i64,
    pub total_size_bytes: i64,
    pub schema_version: String,
    pub created_at: String,
}

impl ExportAuditRecord {
    pub fn new(
        user_id: String,
        project_id: String,
        export_type: String,
        manifest_hash: String,
        asset_count: i64,
        missing_asset_count: i64,
        total_size_bytes: i64,
    ) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            user_id,
            project_id,
            export_type,
            manifest_hash,
            asset_count,
            missing_asset_count,
            total_size_bytes,
            schema_version: "1.0.0".to_string(),
            created_at: Utc::now().to_rfc3339(),
        }
    }
}
