use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct Session {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    #[serde(rename = "userId")]
    #[sqlx(rename = "user_id")]
    pub user_id: String,
    #[serde(rename = "startedAt")]
    #[sqlx(rename = "started_at")]
    pub started_at: String,
    #[serde(rename = "endedAt", skip_serializing_if = "Option::is_none")]
    #[sqlx(rename = "ended_at")]
    pub ended_at: Option<String>,
    #[serde(rename = "changeSummary", skip_serializing_if = "Option::is_none")]
    #[sqlx(rename = "change_summary")]
    pub change_summary: Option<String>,
}

impl Session {
    pub fn new(project_id: String, user_id: String) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            user_id,
            started_at: Utc::now().to_rfc3339(),
            ended_at: None,
            change_summary: None,
        }
    }
}
