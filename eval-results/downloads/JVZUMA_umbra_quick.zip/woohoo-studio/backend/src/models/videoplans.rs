use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct VideoPlan {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    pub name: String,
    pub model: String,
    pub resolution: String,
    pub fps: i64,
    pub duration: f64,
    pub parameters: String,
    #[serde(rename = "createdAt")]
    #[sqlx(rename = "created_at")]
    pub created_at: String,
    #[serde(rename = "updatedAt")]
    #[sqlx(rename = "updated_at")]
    pub updated_at: String,
}

impl VideoPlan {
    pub fn new(project_id: String, name: String, model: String,
               resolution: serde_json::Value, fps: i64, duration: f64,
               parameters: serde_json::Value) -> Self {
        let now = Utc::now().to_rfc3339();
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            name,
            model,
            resolution: resolution.to_string(),
            fps,
            duration,
            parameters: parameters.to_string(),
            created_at: now.clone(),
            updated_at: now,
        }
    }
}
