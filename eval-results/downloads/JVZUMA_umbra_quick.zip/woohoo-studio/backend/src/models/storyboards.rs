use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct Storyboard {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    pub name: String,
    pub shots: String,
    #[serde(rename = "createdAt")]
    #[sqlx(rename = "created_at")]
    pub created_at: String,
    #[serde(rename = "updatedAt")]
    #[sqlx(rename = "updated_at")]
    pub updated_at: String,
}

impl Storyboard {
    pub fn new(project_id: String, name: String, shots: Vec<serde_json::Value>) -> Self {
        let now = Utc::now().to_rfc3339();
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            name,
            shots: serde_json::to_string(&shots).unwrap_or_else(|_| "[]".to_string()),
            created_at: now.clone(),
            updated_at: now,
        }
    }
}
