use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct Asset {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    pub name: String,
    #[serde(rename = "type")]
    #[sqlx(rename = "type")]
    pub kind: String,
    pub url: String,
    #[serde(rename = "sizeBytes", skip_serializing_if = "Option::is_none")]
    #[sqlx(rename = "size_bytes")]
    pub size_bytes: Option<i64>,
    #[serde(rename = "mimeType", skip_serializing_if = "Option::is_none")]
    #[sqlx(rename = "mime_type")]
    pub mime_type: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sha256: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<String>,
    #[serde(rename = "createdAt")]
    #[sqlx(rename = "created_at")]
    pub created_at: String,
    #[serde(skip)]
    #[sqlx(rename = "file_data")]
    pub file_data: Option<Vec<u8>>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateAsset {
    pub name: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub url: String,
    #[serde(default, rename = "sizeBytes")]
    pub size_bytes: Option<i64>,
    #[serde(default, rename = "mimeType")]
    pub mime_type: Option<String>,
    #[serde(default)]
    pub sha256: Option<String>,
    #[serde(default)]
    pub metadata: Option<serde_json::Value>,
}

impl Asset {
    pub fn new(project_id: String, name: String, kind: String, url: String,
               size_bytes: Option<i64>, mime_type: Option<String>, sha256: Option<String>,
               metadata: Option<serde_json::Value>, file_data: Option<Vec<u8>>) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            name,
            kind,
            url,
            size_bytes,
            mime_type,
            sha256,
            metadata: metadata.map(|m| m.to_string()),
            created_at: Utc::now().to_rfc3339(),
            file_data,
        }
    }
}
