use chrono::Utc;
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
#[serde(rename_all = "camelCase")]
pub struct Keyframe {
    pub id: String,
    #[serde(rename = "projectId")]
    #[sqlx(rename = "project_id")]
    pub project_id: String,
    pub name: String,
    #[serde(rename = "assetId", skip_serializing_if = "Option::is_none")]
    #[sqlx(rename = "asset_id")]
    pub asset_id: Option<String>,
    pub timestamp: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub annotations: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub prompt: Option<String>,
    #[serde(rename = "createdAt")]
    #[sqlx(rename = "created_at")]
    pub created_at: String,
}

impl Keyframe {
    pub fn new(project_id: String, name: String, asset_id: Option<String>, timestamp: f64,
               annotations: Option<String>, prompt: Option<String>) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            project_id,
            name,
            asset_id,
            timestamp,
            annotations,
            prompt,
            created_at: Utc::now().to_rfc3339(),
        }
    }
}
