-- Woohoo Studio initial schema
-- All tables use TEXT UUIDs as primary keys and ISO-8601 timestamps.

CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    owner_id TEXT NOT NULL,
    settings TEXT,  -- JSON
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scripts (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    scenes TEXT NOT NULL DEFAULT '[]',  -- JSON array
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scripts_project ON scripts(project_id);

CREATE TABLE IF NOT EXISTS storyboards (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    shots TEXT NOT NULL DEFAULT '[]',  -- JSON array
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_storyboards_project ON storyboards(project_id);

CREATE TABLE IF NOT EXISTS keyframes (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    asset_id TEXT,
    timestamp REAL NOT NULL DEFAULT 0,
    annotations TEXT,
    prompt TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_keyframes_project ON keyframes(project_id);

CREATE TABLE IF NOT EXISTS video_plans (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    model TEXT NOT NULL DEFAULT '',
    resolution TEXT NOT NULL DEFAULT '{}',  -- JSON {width, height}
    fps INTEGER NOT NULL DEFAULT 24,
    duration REAL NOT NULL DEFAULT 0,
    parameters TEXT NOT NULL DEFAULT '{}',  -- JSON
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_videoplans_project ON video_plans(project_id);

CREATE TABLE IF NOT EXISTS assets (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    url TEXT NOT NULL,
    size_bytes INTEGER,
    mime_type TEXT,
    sha256 TEXT,
    metadata TEXT NOT NULL DEFAULT '{}',  -- JSON
    file_data BLOB,  -- optional in-database storage for small assets
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assets_project ON assets(project_id);

CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    change_summary TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_id);

-- Export audit logs (new table for delivery audit)
-- Rationale: Dedicated table instead of generic ops/action audit because:
--  1. Exports carry compliance-relevant fields (manifest hash, asset counts, missing counts)
--     that don't fit into a generic action log without heavy JSON blobbing.
--  2. Query pattern is always "list exports for a project, ordered by time" — a dedicated
--     narrow table gives fast indexed reads and clear schema.
--  3. Retention policies for exports may differ from generic ops logs.
--  4. Schema can evolve independently (e.g. add file_size_sum, checksum_algo) without
--     touching a shared audit table used by other features.
CREATE TABLE IF NOT EXISTS export_audit_logs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    export_type TEXT NOT NULL,           -- 'full' | 'core' | 'snapshot'
    manifest_hash TEXT NOT NULL,         -- SHA-256 of manifest.json
    asset_count INTEGER NOT NULL DEFAULT 0,
    missing_asset_count INTEGER NOT NULL DEFAULT 0,
    total_size_bytes INTEGER NOT NULL DEFAULT 0,
    schema_version TEXT NOT NULL DEFAULT '1.0.0',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_export_audit_project ON export_audit_logs(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_export_audit_user ON export_audit_logs(user_id, created_at DESC);
