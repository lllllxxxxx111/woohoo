# Woohoo Studio TRAE Demo 提交包

这是基于当前完整项目的 Demo 提交材料，不是另起一个展示页。

## Demo 入口

### 方式 A：本地开发模式

```bash
npm install
npm run dev:all
```

访问：

- 前端：http://127.0.0.1:1420
- 后端健康检查：http://127.0.0.1:8080/health

当前本机已创建演示账号：

- 邮箱：`trae-demo@woohoo.local`
- 密码：`Woohoo2026`

如果换环境运行，也可以在登录页直接注册任意邮箱账号，密码需不少于 8 位且包含字母和数字。

### 方式 B：GitHub + Docker Demo 模式（推荐给评审）

```bash
git clone https://github.com/lllllxxxxx111/woohoo.git
cd woohoo
git checkout codex/agent-eval-good-features
docker compose up --build
```

访问：

- 前端：http://127.0.0.1:18080
- 后端健康检查：http://127.0.0.1:18081/health

Docker 环境首次启动后直接注册账号即可。

如果已经下载了提交附件 `woohoo-studio-trae-demo-20260703.zip`，也可以解压后在解压目录直接运行：

```bash
docker compose up --build
```

## 建议演示脚本

1. 打开登录页，使用演示账号登录或新注册。
2. 展示首页工作台：左侧项目/智能体，中间创意对话，顶部视图切换。
3. 在创意对话输入一个短剧创意，例如：

   ```text
   做一个 60 秒短剧：外卖骑手误入未来城市，用一单外卖改变 AI 市长的决策。
   ```

4. 展示多智能体能力：大纲架构师、人设生成专家、分镜渲染师、合规审核官、主编统筹官、项目管理官。
5. 切到「制作流程」，展示从大纲、剧本、章节、角色场景、关键帧到视频的产线化流程。
6. 切到「图片生成」，展示提示词、模型/尺寸配置和资产入库能力。
7. 切到「资产库」，展示图片、视频、音频、文档统一管理。
8. 点击「预览视图」，展示服务端真实管线监控和 SSE 任务状态。
9. 点击右上角导出，展示「完整项目工程包」和「核心策划包」导出能力。

## 已完成验证

- `npm run typecheck`：通过
- `cargo check --manifest-path server/Cargo.toml`：通过
- `npm run build`：通过
- 本地服务健康检查：`GET http://127.0.0.1:8080/health` 返回 `status: ok`
- 前端开发服务：`GET http://127.0.0.1:1420/` 返回 `200`

## 提交材料文件

- `submission-post.md`：可直接复制到 TRAE 论坛的作品帖草稿
- `how-to-publish.md`：按官方发布指南整理的发帖步骤
- `key-steps-prompts.md`：关键步骤截图和 TRAE Session ID 的提示词
- `session-ids.md`：TRAE Session ID 和截图补充清单
- `README.md`：本文件，包含运行方式和演示脚本
- `screenshots/01-login.png`：已生成的登录页截图
